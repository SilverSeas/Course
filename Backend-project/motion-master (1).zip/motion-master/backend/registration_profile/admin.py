from django.contrib import admin

from registration_profile.models import RegistrationProfile

admin.site.register(RegistrationProfile)
