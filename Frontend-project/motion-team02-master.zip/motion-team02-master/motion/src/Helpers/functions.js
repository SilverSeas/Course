export const time=(date)=>{
    const minutes = (Date.now()-date)/1000/60

const hours = (Date.now()-date)/1000/60/60
const days = (Date.now()-date)/1000/60/60/24

const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];


let time = ''

 if (minutes<50) time ='Just Now'
 else if (hours<24) time = Math.round(hours)+'h ago'
 else if (days<2) time = 'yesterday'
 else if (days<10) time = Math.round(days)+' days ago'
 else time = `${months[date.getMonth()]} ${date.getDate()}`

 return time
}