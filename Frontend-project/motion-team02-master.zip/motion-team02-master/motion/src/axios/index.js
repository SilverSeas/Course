import axios from 'axios';

const baseURL = 'https://motion.propulsion-home.ch/backend/api/'

export const MotionBase = axios.create({
    baseURL: baseURL ,
});

export const MotionToken = axios.create({
    baseURL: baseURL,
    
    timeout: 10000,
    headers: {
        'Authorization': `Bearer ${localStorage.getItem('access')}`,
        'Content-Type': 'application/json'
    }
})

