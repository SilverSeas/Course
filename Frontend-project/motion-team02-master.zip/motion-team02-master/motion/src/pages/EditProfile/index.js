import React from "react";
import { ProfilePageElements } from "./styled.EditProfile";
import EditProfile from "../../Components/Profile/EditProfile";

export default function EditProfilePage() {
  return (
    <ProfilePageElements>
      <EditProfile></EditProfile>
    </ProfilePageElements>
  );
}
