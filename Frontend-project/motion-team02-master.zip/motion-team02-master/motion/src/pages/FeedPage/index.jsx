import React from 'react'
import FeedContainerComponent from '../../Components/FeedComponents/FeedContainer'
import Header from '../../Components/Header'



const FeedPage = () => {





  return (
    <>
    {/* <div>FeedPage</div> */}
    {/* <button onClick={()}></button> */}
    {/* <Header/> */}
    <FeedContainerComponent/>
    
    </>
  )
}

export default FeedPage