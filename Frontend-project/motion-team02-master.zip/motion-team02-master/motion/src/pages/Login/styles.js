import styled from 'styled-components'
import backgroundImg from '../../assets/images/background_image.png'

export const Cont = styled.div`
    height: 100vh;
    width: 100%;
    display: flex;
`

export const Left = styled.section`
    background-image: url(${backgroundImg}), linear-gradient(132.96deg, #C468FF 3.32%, #6E91F6 100%);
    background-repeat: no-repeat;
    background-size: cover;
    height: 100vh;
    width: 40%;
    display: flex;
    flex-direction: column;

    h1 {
        font-family: Roboto;
        font-style: normal;
        font-weight: 500;
        font-size: 3rem;
        line-height: 35px;
        text-align: center;
        letter-spacing: 0.75px;
        color: #FFFFFF;
        margin-bottom: 50px;
    }
`

export const LeftCont = styled.div`
    height: 70%;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    align-items: center;
    
    p {
        width: 28rem;
        word-wrap: break-word;
        font-family: Roboto;
        font-style: normal;
        font-weight: 500;
        font-size: 1.6rem;
        line-height: 24px;
        text-align: center;
        color: #FFFFFF;
        mix-blend-mode: normal;
        opacity: 0.6;
        margin-bottom: 25px;
        line-height: 25px;
        column-gap: 40px;
    } 
`
export const MotionLogo = styled.img`
    height: 80px;
    width: 80px;
    color: #fff;
    margin-bottom: 20px;
    box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.07);
`

export const FotterCont = styled.div`
    display: flex;
    justify-self: flex-end;
    align-items: center;
    flex-direction: column;
    margin-top: 90px;    

    p {            
        margin-top: 40px;
        font-size: 1.2rem;
        line-height: 14px;
        text-align: center;
        color: #FFFFFF;
        font-weight: 400;
    }

    footer {
        display: flex;
        justify-content: center;
        align-items: center;    
    }
`

export const StoreBtNContainer = styled.div`
display: flex;
justify-content: space-evenly;
align-items: center;
width: 268px;
margin: 10px;
`

export const Right = styled.section`
    display: flex;
    flex-direction: column;
    width: 60%;
    height: 100vh;
`

export const HeaderBtNCont = styled.div`
    display: flex;
    margin-top: calc(40px - 14px);
    justify-content: flex-end;    

    header { 
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        padding-right: 40px;
        font-size: 1.4rem;
        p {
            font-size: 1.4rem;
            line-height: 16px;
        }
    }
`

export const RightCont = styled.main`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100vh;

    h2 {
        display: flex;
        justify-content: center;
        font-size: 4rem;
        line-height: 47px;
        font-family: Roboto;
        font-style: normal;
        font-weight: 500;
        margin-bottom: 45px;
    }

    form {
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 100%;
        width: 100%;
        flex-direction: column;
    }
`

export const LoginCont = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: calc(100vh - 80px - 26px);
    //padding-top: calc(128px - 20px); mark

    p {
        height: 16px;
        font-size: 1.4rem;
    }

    input {
        border: none;
        padding: 0 0 0 0;
        opacity: 100%;
        line-height: 26px;
        font-size: 1.6rem;

        &#user, &#password {
            width: 100%;
        }
    }

    input::-webkit-input-placeholder {
        color: black;
        opacity: 1;
    }

    input:focus {
        outline: none;
    }
    
    label {
        display: flex;
        align-self: center;
        justify-content: center;
    }
`

export const StepLoginCont = styled.div`
    #submit {
        margin-top: min(160px, 140px);
        margin-bottom: calc(55px + 62px + 9px);
        min-height: 60px;
    }
`

export const AppleBtN = styled.button`
    width: 126px;
    height: 40px;
    background: transparent;
    padding-top: 2px;
    margin-right: 8px;
    border: 2px solid rgba(255, 255, 255, 0.2);
    border-radius: 100px;
    :hover {
        background: rgba(255, 255, 255, 0.2);
    } 
`

export const GoogleBtN = styled.button`
    width: 126px;
    height: 40px;
    background: transparent;
    padding-top: 7px;
    margin-right: 8px;
    border: 2px solid rgba(255, 255, 255, 0.2);
    border-radius: 100px;
    :hover {
        background: rgba(255, 255, 255, 0.2);
    } 
`

export const TwitterBtN = styled.button`
    width: 40px;
    height: 40px;
    background: none;
    border: none;
    opacity: 0.2; 
    padding-bottom: -10px;  
    :hover {
        opacity: 1;
    }   
`

export const FacebookBtN = styled.button`
    width: 40px;
    height: 40px;
    background: none;
    border: none;
    margin-right: 16px; 
    margin-left: 16px; 
    opacity: 0.2;   
    :hover {
        opacity: 1;
    } 
`

export const InstagramBtN = styled.button`
    width: 40px;
    height: 40px;
    background: none;
    border: none;
    opacity: 0.2;  
    :hover {
        opacity: 1;
    } 
`

export const NextStepBtN = styled.button`
    display: flex;
    align-items: center;
    align-self: center;
    padding-top: 16px;
    justify-items: center;
    align-content: center;    
    background: linear-gradient(132.96deg, #C468FF 3.32%, #6E91F6 100%);
    color: #ffff;
    border-radius: 30px;
    width: 280px;
    height: 60px;
    border: 2px solid rgba(200, 200, 200, 0.45);
    box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.07);
    margin-top: 20%;

    font-family: Roboto;
    font-style: normal;
    font-weight: normal;
    font-size: 12px;
    line-height: 14px;

    text-align: center;
    letter-spacing: 1px;
    text-transform: uppercase;

    color: #FFFFFF;

    input {
        width: 280px;
    }
`

export const SignBtN = styled.button`
    background: transparent;
    padding: 14px;
    border: 1px solid rgba(0, 0, 0, 0.2);
    box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.07);
    border-radius: 30px; 
    display: flex;
    align-items: center;
    justify-content: center;
    width: 120px;
    height: 40px;
    margin: 20px;

    font-family: Roboto;
    font-style: normal;
    font-weight: normal;
    font-size: 10px;
    line-height: 12px;
    /* === box height */

    text-align: center;
    letter-spacing: 1px;
    text-transform: uppercase;

    color: #000000;

    :hover {
        background: rgba(0, 0, 0, 0.07);
    }
`

export const SocialLinksCont = styled.div`
color: #FFFFFF;
`