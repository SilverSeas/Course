// import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
// IMP REDUCERS TO USE
import { change_sub } from '../../redux/slices/login';
// IMP LOGO (lS)
import MotionLogoPic from '../../assets/images/logo_white.png';
// IMP SOCIAL-MEDIA-ICONS (LS)
import TwitterIcon from '../../assets/svgs/twitter_icon.svg'
import FacebookIcon from '../../assets/svgs/facebook_icon.svg'
import InstagramIcon from '../../assets/svgs/instagram_icon.svg'
// IMP SIGN-IN & SIGNUP-STEPONE TO RERENDER "IN" (RS)
import SignIn from "../../Components/SignComponents/SignIn"
import SignUpStepOne from "../../Components/SignComponents/SignUpStepOne"
import SignUpStepTwo from "../../Components/SignComponents/SignUpStepTwo"
import SignUpStepThree from "../../Components/SignComponents/SignUpStepThree"
// IMP ASSETS
import { ReactComponent as AppleSVG } from '../../assets/svgs/apple.svg';
import { ReactComponent as GoogleSVG } from '../../assets/svgs/google.svg';
// IMP STYLED COMPONENTS 
import { Cont, Left, LeftCont, MotionLogo, StoreBtNContainer, AppleBtN, GoogleBtN, SocialLinksCont, TwitterBtN, FacebookBtN, InstagramBtN, Right, HeaderBtNCont, SignBtN,RightCont, LoginCont } from './styles'

const Login = () => {

    const dispatch = useDispatch()

    const currentSubComp = useSelector(state => state.loginData.sub)  

    const toggleSignInSignUp = () => {
        if (currentSubComp === "Sign In") {
            dispatch(change_sub("Step One"))
        }
        else {
            dispatch(change_sub("Sign In"))
        }
    }

    return (<>
        <Cont >
            <Left>
                <LeftCont>
                    <MotionLogo src={MotionLogoPic} alt="Motion Logo"/>
                    <h1>Motion</h1>
                    <p>Connect with friends and the world around you with Motion.</p>
                    <StoreBtNContainer>
                        <AppleBtN><AppleSVG /></AppleBtN>
                        <GoogleBtN><GoogleSVG /></GoogleBtN>
                    </StoreBtNContainer>
                </LeftCont>
                <SocialLinksCont>
                    <footer>
                        <TwitterBtN><img src={TwitterIcon} width={46} height={46} alt="Twitter Icon"/></TwitterBtN>
                        <FacebookBtN><img src={FacebookIcon} width={40} height={40} alt="Facebook Icon"/></FacebookBtN>
                        <InstagramBtN><img src={InstagramIcon} width={40} height={40} alt="Instagram Icon"/></InstagramBtN>
                    </footer>
                    <p>© Motion 2018. All rights reserved.</p>
                </SocialLinksCont>
            </Left>
            <Right>
                {currentSubComp === "Sign In" || currentSubComp === "Step One" ?           
                    <HeaderBtNCont>
                        {currentSubComp === "Sign In" ? <>Don't have an account?</> : <>Already have an account?</>}
                        <SignBtN onClick={() => toggleSignInSignUp()}>
                            {currentSubComp ===  "Sign In" ? <>Sign Up</> : <>Sign In</>}
                        </SignBtN>
                    </HeaderBtNCont>
                : "" }

                <RightCont>
                    <LoginCont>
                    {currentSubComp === "Sign In" ? <SignIn/> : "" }
                    {currentSubComp === "Step One" ? <SignUpStepOne/> : "" }
                    {currentSubComp === "Step Two" ? <SignUpStepTwo/> : "" }
                    {currentSubComp === "Step Three" ? <SignUpStepThree/> : "" }
                    </LoginCont>
                </RightCont>
            </Right>
        </Cont>
    </>)
}

export default Login 