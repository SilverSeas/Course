import React from "react";
import Profile from "../../Components/Profile";
import { ProfilePageElements, BoxAroundFeed } from "./styled.Profile";
import FeedContainerComponent from "../../Components/FeedComponents/FeedContainer";

export default function ProfilePage() {
  return (
    <>
      <ProfilePageElements>
        <Profile></Profile>
      </ProfilePageElements>
      <BoxAroundFeed>
        <FeedContainerComponent></FeedContainerComponent>
      </BoxAroundFeed>
    </>
  );
}
