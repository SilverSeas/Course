import styled from "styled-components";

export const ProfilePageElements = styled.div`
  display: flex;
  width: 100%;
  height: 50%;
`;

export const BoxAroundFeed = styled.div.attrs({
  className: "ProfileStyle ",
})`
  display: flex;
  padding-top: 30vh;
`;

export const ProfileStyle = styled.div.attrs({
  className: "ProfileStyle ",
})`
  display: flex;
  position: relative;
  flex-direction: column;
  justify-content: center;
  justify-items: center;
  align-items: center;
  align-content: center;
  padding-bottom: 10vh;
`;
