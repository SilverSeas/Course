import { configureStore } from "@reduxjs/toolkit";
import currentUserSlice from "./slices/auth";
import ProfileReducer from "./slices/profile";
import LoginSlice from "./slices/login";

export default configureStore({
  reducer: {
    currentUser: currentUserSlice,
    getProfile: ProfileReducer,
    loginData: LoginSlice
  },
});
