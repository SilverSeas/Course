import { createSlice } from "@reduxjs/toolkit";

export const profileSlice = createSlice({
  name: "profile",
  initialState: {
    storage: [
      {
        id: 2254,
        email: "lanipep310@wiroute.com",
        first_name: "Hatice",
        last_name: "Anik",
        username: "HA",
        job: "",
        avatar:
          "https://motion.propulsion-home.ch/media-files/rod-sot-X_vbB7wfv5k-unsplash_1.jpg",
        banner: null,
        location: "",
        phone_number: "",
        about_me: "",
        things_user_likes: [],
        logged_in_user_is_following: false,
        logged_in_user_is_friends: false,
        logged_in_user_is_rejected: false,
        logged_in_user_received_fr: false,
        logged_in_user_sent_fr: false,
        amount_of_posts: 0,
        amount_of_likes: 0,
        amount_of_friends: 2,
        amount_of_followers: 0,
        amount_following: 0,
      },
      {
        id: 2239,
        email: "laysa.uchoa@gmail.com",
        first_name: "Laysa2",
        last_name: "Uchoa2",
        username: "laysauchoa2",
        job: "Dancer",
        avatar:
          "https://motion.propulsion-home.ch/media-files/150_qG0kpcm.jpeg",
        banner:
          "https://motion.propulsion-home.ch/media-files/banner_oIWrUjN.png",
        location: "Munich",
        phone_number: "+49 5476-2356",
        about_me: "I like dancing, travelling and meeting new people.",
        things_user_likes: ["baking", "dancing"],
        logged_in_user_is_following: false,
        logged_in_user_is_friends: false,
        logged_in_user_is_rejected: false,
        logged_in_user_received_fr: false,
        logged_in_user_sent_fr: false,
        amount_of_posts: 7,
        amount_of_likes: 0,
        amount_of_friends: 4,
        amount_of_followers: 0,
        amount_following: 0,
      },
    ],
  },
  reducers: {
    addUsers: (state, action) => {
      console.log("====>>>>>>HEREEEE:::::::");
      console.log(action.payload);
    },
    addFriend: (state, action) => {
      const profileToAdd = action.payload;
      const index = state.storage.findIndex(
        (profile) => profile.id === profileToAdd.id
      );
      state.storage[index].logged_in_user_is_friends = true;
    },
    follow: (state, action) => {
      const profileToFollow = action.payload;
      const index = state.storage.findIndex(
        (profile) => profile.id === profileToFollow.id
      );
      state.storage[index].logged_in_user_sent_fr = true;
    },
  },
});

export const { addFriend, follow, addUsers } = profileSlice.actions;
export default profileSlice.reducer;
