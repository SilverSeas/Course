import { createSlice } from "@reduxjs/toolkit";

export const LoginSlice = createSlice({
  
    name: "loginData",
    initialState: {
      sub: "Sign In"
    },
    reducers: {
      change_sub: (state, action) => {
        state.sub = action.payload;
      },
    },
});
  
  export const { change_sub } = LoginSlice.actions;
  export default LoginSlice.reducer;