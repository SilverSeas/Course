import { createSlice } from "@reduxjs/toolkit";

export const currentUserSlice = createSlice({
  name: "currentUser",
  initialState: {
    tokens: {
      access: "",
      refresh: "",
      
    },
    user: {}
  },
  reducers: {
    setToken: (state, action) => {
      state.tokens.access = action.payload.access;
      state.tokens.refresh = action.payload.refresh;
      state.user = action.payload.user;
    },
  },
});

export const { setToken } = currentUserSlice.actions;
export default currentUserSlice.reducer;
