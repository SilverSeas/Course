import { Routes, Route } from "react-router-dom";
import FindFriends from "./Components/Friends/FindFriends";
import FriendRequests from "./Components/Notification/FriendRequests";
import FeedPage from "./pages/FeedPage";
import "./App.css";
import SignInEasy from "./Components/SignComponents/SignIn/SignInEasy";
import ProfilePage from "./pages/Profile";
import EditProfilePage from "./pages/EditProfile";
import Header from "./Components/Header";
import Login from "./pages/Login";

function App() {
  return (
    <div className="App">
      <Header>
        <Routes>
          <Route path="/loginpage" element={<Login />} />
          <Route path="/login" element={<SignInEasy />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/edit-profile" element={<EditProfilePage />} />
          <Route path="/findfriends" element={<FindFriends />} />
          <Route path="/feed" element={<FeedPage />} />
          <Route path="/notification" element={<FriendRequests />} />
        </Routes>
      </Header>
    </div>
  );
}

export default App;
