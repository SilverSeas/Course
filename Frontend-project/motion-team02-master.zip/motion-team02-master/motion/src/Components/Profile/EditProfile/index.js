import { useState, useEffect } from "react";
import { MotionToken } from "../../../axios";
import {
  EditProfileBox,
  EditProfileElements,
  EditProfileForm,
  EditFormInput,
  InputFormBox,
  InputFormValue,
  InputFormTextArea,
  InputFormBoxTextArea,
} from "./EditProfile.styled";
import Banner from "../Banner";
import SideProfileEdit from "./SideEditProfile";

const EditProfile = (props) => {
  const [profile, setProfile] = useState({});

  useEffect(() => {
    const fetchData = async () => {
      const result = await MotionToken("users/me/");
      setProfile(result.data);
      console.log("Current profile: ", profile);
    };
    fetchData();
  }, []);

  const handleTodoChange = (event) => {
    let newProfileCopy = { ...profile };
    newProfileCopy[event.target.id] = event.target.value;
    setProfile(newProfileCopy);
    console.log("hereeee", profile);
  };
  // onSubmit={(e) => handleSubmit(e)}
  return (
    <EditProfileElements>
      <EditProfileBox>
        <SideProfileEdit profile={profile}></SideProfileEdit>
        <EditProfileForm>
          <InputFormBox>
            <h1>First name</h1>
            <InputFormValue
              id="first_name"
              type={"text"}
              value={profile.first_name ? profile.first_name : ""}
              placeholder={profile.first_name ? profile.first_name : ""}
              onChange={(event) => handleTodoChange(event)}
            ></InputFormValue>
          </InputFormBox>
          <InputFormBox>
            <h1>Last name</h1>
            <InputFormValue
              id="last_name"
              type={"text"}
              value={profile.last_name ? profile.last_name : ""}
              placeholder={profile.last_name ? profile.last_name : ""}
              onChange={(event) => handleTodoChange(event)}
            ></InputFormValue>
          </InputFormBox>
          <InputFormBox>
            <h1>E-mail</h1>
            <InputFormValue
              id="email"
              type={"text"}
              value={profile.email ? profile.email : ""}
              placeholder={profile.email ? profile.email : ""}
              onChange={(event) => handleTodoChange(event)}
            ></InputFormValue>
          </InputFormBox>
          <InputFormBox>
            <h1>Username</h1>
            <InputFormValue
              id="username"
              type={"text"}
              value={profile.username ? profile.username : ""}
              placeholder={profile.username ? profile.username : ""}
              onChange={(event) => handleTodoChange(event)}
            ></InputFormValue>
          </InputFormBox>
          <InputFormBox>
            <h1>Location</h1>
            <InputFormValue
              id="location"
              type={"text"}
              value={profile.location ? profile.location : ""}
              // placeholder={profile.location ? profile.location : ""}
              onChange={(event) => handleTodoChange(event)}
            ></InputFormValue>
          </InputFormBox>
          <InputFormBox>
            <h1>Phone</h1>
            <InputFormValue
              id="phone_number"
              type={"text"}
              value={profile.phone_number ? profile.phone_number : ""}
              onChange={(event) => handleTodoChange(event)}
            ></InputFormValue>
          </InputFormBox>
          <InputFormBoxTextArea>
            <h1>About me</h1>
            <InputFormTextArea
              id="about_me"
              type={"text"}
              value={profile.about_me ? profile.about_me : ""}
              onChange={(event) => handleTodoChange(event)}
            ></InputFormTextArea>
          </InputFormBoxTextArea>
          <InputFormBox>
            <h1>Password</h1>
            <InputFormValue
              name="password"
              id="password"
              type={"password"}
              value={profile.password ? profile.password : ""}
              onChange={(event) => handleTodoChange(event)}
            ></InputFormValue>
          </InputFormBox>

          {/* <InputFormBox>
            <h1>Things user likes</h1>
            <InputFormValue
              id="things_user_likes"
              type={"text"}
              value={
                profile.things_user_likes
                  ? profile.things_user_likes
                  : profile.things_user_likes
              }
              // placeholder={profile.things_user_likes ? profile.things_user_likes : ""}
              onChange={(event) => handleTodoChange(event)}
            ></InputFormValue>
          </InputFormBox>
          <button>Add</button> */}
        </EditProfileForm>
      </EditProfileBox>
      <Banner></Banner>
    </EditProfileElements>
  );
};
export default EditProfile;
