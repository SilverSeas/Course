import styled from "styled-components";

export const EditProfileElements = styled.div.attrs({
  className: "EditProfileElements",
})`
  display: flex;
  width: 99vw;
  height: 100vh;
`;

export const EditProfileForm = styled.form.attrs({
  className: "EditProfileForm",
})`
  display: flex;
  width: 80%;
  height: 80%;

  background-color: #ffffff;
  background: #ffffff;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  flex-wrap: wrap;
  padding: 50px;
`;

export const EditProfileBox = styled.div.attrs({
  className: "EditProfileBox",
})`
  display: flex;

  z-index: 1;
  position: absolute;
  border: rgb(0, 0, 0, 0.1) 1px solid;
  width: 1152px;
  height: 600px;
  left: 144px;
  top: 200px;
  background-color: #ffffff;
  background: #ffffff;
  box-shadow: 0px 0px 1px rgba(0, 0, 0, 0.2), 0px 10px 20px rgba(0, 0, 0, 0.05);
  border-radius: 4px;
`;

export const InputFormValue = styled.input.attrs({
  className: "InputFormValue",
})`
  display: flex;
  width: 300px;
  height: 30px;
  font-family: "Roboto";
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 26px;
  border: none;
  flex-wrap: wrap;
  /* identical to box height, or 162% */
`;

export const InputFormBox = styled.div.attrs({
  className: "InputFormBox",
})`
  display: flex;
  border-bottom: rgb(0, 0, 0, 0.1) 2px solid;
  width: 350px;
  height: 50px;
  flex-direction: column;
  align-items: flex-start;
  padding-bottom: 10px;
  padding-left: 15px;

  h1 {
    display: flex;
    align-items: flex-start;
    font-family: "Roboto";
    font-style: normal;
    font-weight: 400;
    font-size: 12px;
    line-height: 14px;
    color: #000000;

    mix-blend-mode: normal;
    opacity: 0.5;
  }
`;

export const InputFormBoxTextArea = styled.div.attrs({
  className: "InputFormBoxTextArea ",
})`
  display: flex;
  border-bottom: rgb(0, 0, 0, 0.1) 2px solid;
  width: 350px;
  height: 100px;
  flex-direction: column;
  align-items: flex-start;
  padding-bottom: 10px;
  padding-left: 15px;

  h1 {
    display: flex;
    align-items: flex-start;
    font-family: "Roboto";
    font-style: normal;
    font-weight: 400;
    font-size: 12px;
    line-height: 14px;
    color: #000000;

    mix-blend-mode: normal;
    opacity: 0.5;
  }
`;

export const InputFormTextArea = styled.textarea.attrs({
  className: "InputFormValue",
})`
  display: flex;
  width: 300px;
  height: 200px;
  font-family: "Roboto";
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 26px;
  border: none;
  flex-wrap: wrap;
`;
