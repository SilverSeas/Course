import { useState, useEffect } from "react";
import { MotionToken } from "../../../../axios";
import React from "react";
import { FiUpload } from "react-icons/fi";
import { AiOutlineDelete } from "react-icons/ai";
import {
  SideBarEdit,
  ProfileImage,
  FontSubTitle,
  FontTitle,
  ProfileButton,
  PurpleButton,
  WhiteButton,
  HoldButtons,
  UploadAndRemoveElements,
  UploadButton,
} from "./styledSideEditProfile";
import { toBeRequired } from "@testing-library/jest-dom/dist/matchers";

const SideProfileEdit = (props) => {
  const [friends, setFriends] = useState(undefined);
  const [previewImage, setPreviewImage] = useState(undefined);
  const hiddenFileInput = React.useRef(null);
  const [files, setFiles] = useState([]);
  const formData = new FormData();

  const seeProfiles = () => {
    alert("hre");
  };
  const editProfile = () => {
    console.log("hy");
  };
  const handleSubmit = async (event) => {
    event.preventDefault();
    delete props.profile["avatar"];
    delete props.profile["banner"];
    delete props.profile["password"];

    let config = {
      method: "patch",
      maxBodyLength: Infinity,
      url: "https://motion.propulsion-home.ch/backend/api/users/me/",
      data: props.profile,
    };
    console.log("Config: ", config);

    let patchResponse = await MotionToken(config);
    console.log("Response: ", patchResponse);

    const fetchData = async () => {
      const result = await MotionToken("users/me/");
      console.log("Profile update to ", props.profile);
    };
    fetchData();
  };
  const onFileChange = (e) => {
    setFiles(e.target.files[0]);
    setPreviewImage(URL.createObjectURL(e.target.files[0]));
  };
  const sendPost = async (e) => {
    formData.append("avatar", files);

    let config = {
      headers: {
        "Content-Type": "multipart/form-data",
      },
      method: "patch",
      maxBodyLength: Infinity,
      url: "https://motion.propulsion-home.ch/backend/api/users/me/",
      data: formData,
    };

    let postResponse = await MotionToken(config);
    console.log(postResponse);
  };
  const sendPostRemove = async (e) => {
    setFiles([]);
    formData.append("avatar", files);

    let config = {
      headers: {
        "Content-Type": "multipart/form-data",
      },
      method: "patch",
      maxBodyLength: Infinity,
      url: "https://motion.propulsion-home.ch/backend/api/users/me/",
      data: formData,
    };

    let postResponse = await MotionToken(config);
    console.log(postResponse);
  };
  const handleClick = (event) => {
    hiddenFileInput.current.click();
  };

  // const fetchData = async () => {
  //   const response = await MotionToken("users/me/");

  //   setFriends("Results", response.data.results);
  // };

  return (
    <SideBarEdit>
      <ProfileImage
        className="ProfileImage"
        src={props.profile.avatar ? props.profile.avatar : ""}
        alt={props.profile.first_name ? props.profile.first_name : ""}
      />
      <FontTitle>{props.profile.first_name}</FontTitle>
      <FontSubTitle>{props.profile.location}</FontSubTitle>
      <ProfileButton onClick={(e) => sendPost(e)}>Update Profile</ProfileButton>
      <input
        type="file"
        ref={hiddenFileInput}
        onChange={onFileChange}
        style={{ display: "none" }}
      />
      <UploadAndRemoveElements>
        <UploadButton onClick={handleClick}>
          <span title="hover text">
            {" "}
            <FiUpload> </FiUpload> Upload
          </span>
        </UploadButton>
        <UploadButton onClick={(e) => sendPostRemove(e)}>
          <span title="hover text">
            {" "}
            <AiOutlineDelete> </AiOutlineDelete> Remove
          </span>
        </UploadButton>
      </UploadAndRemoveElements>
      <HoldButtons>
        <WhiteButton onClick={(e) => handleSubmit(e)}>
          <h1>delete account</h1>
        </WhiteButton>
        <PurpleButton onClick={(e) => handleSubmit(e)}>
          <h1>SAVE</h1>
        </PurpleButton>
      </HoldButtons>
    </SideBarEdit>
  );
};
export default SideProfileEdit;
