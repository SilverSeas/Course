import styled from "styled-components";
export const SideBar = styled.div`
  display: flex;
  width: 319px;
  height: 400px;
  border-right: rgb(0, 0, 0, 0.1) 1px solid;
  flex-direction: column;
  display: flex;
  align-items: center;
  justify-content: center;
`;

export const ProfileImage = styled.img`
  background-size: cover;
  background-position: center;
  border-radius: 50%;
  width: 80px;
  height: 80px;
`;

export const FontTitle = styled.h2`
  height: 28px;
  left: 0.32%;
  right: 0.95%;
  top: calc(50% - 28px / 2 + 37px);

  font-family: "Roboto";
  font-style: normal;
  font-weight: 400;
  font-size: 24px;
  line-height: 28px;
  text-align: center;

  color: #000000;
`;

export const ButtonEdit = styled.button`
  mix-blend-mode: normal;
  opacity: 0.2;
  border: 1px solid #000000;
  box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.07);
  border-radius: 30px;
  line-height: 11.72px;
  width: 158px;
  height: 40px;

  h1 {
    font-family: "Roboto";
    font-style: normal;
    font-weight: 400;
    font-size: 10px;
    line-height: 12px;
    /* identical to box height */

    text-align: center;
    letter-spacing: 0.833333px;
    text-transform: uppercase;

    color: #000000;
  }
`;

export const FontSubTitle = styled.h2`
  height: 16px;
  left: 12.66%;
  right: 12.66%;
  top: calc(50% - 16px / 2 + 67px);

  font-family: "Roboto";
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 16px;
  text-align: center;

  color: #000000;
`;
// background: url(Image.png);
