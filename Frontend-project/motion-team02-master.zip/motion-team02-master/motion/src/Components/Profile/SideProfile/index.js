import {
  ProfileImage,
  FontTitle,
  FontSubTitle,
  SideBar,
  ButtonEdit,
} from "./SideProfile.styled.js";
import { useNavigate } from "react-router-dom";

const SideProfile = (props) => {
  const navigate = useNavigate();
  const seeProfiles = () => {
    alert("hre");
  };
  const editProfile = () => {
    return navigate("/edit-profile");
  };

  return (
    <SideBar>
      <ProfileImage
        className="SideProfile"
        src={props.profile.avatar}
        alt={props.profile.first_name}
      />
      <FontTitle>{props.profile.first_name}</FontTitle>
      <FontSubTitle>{props.profile.location}</FontSubTitle>
      <ButtonEdit onClick={editProfile}>
        {" "}
        <h1>EDIT PROFILE</h1>
      </ButtonEdit>
    </SideBar>
  );
};
export default SideProfile;
