import styled from "styled-components";

export const ProfileBox = styled.div.attrs({
  className: "ProfileBox",
})`
  display: flex;
  z-index: 1;
  position: absolute;
  border: rgb(0, 0, 0, 0.1) 1px solid;
  width: 1152px;
  height: 400px;
  left: 144px;
  top: 200px;
  background-color: #ffffff;
  background: #ffffff;
  box-shadow: 0px 0px 1px rgba(0, 0, 0, 0.2), 0px 10px 20px rgba(0, 0, 0, 0.05);
  border-radius: 4px;
`;

export const M = styled.div.attrs({
  className: "M",
})`
  display: flex;
  flex-direction: column;
`;
