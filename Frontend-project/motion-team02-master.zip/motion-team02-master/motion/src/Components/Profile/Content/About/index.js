import styled from "styled-components";
import { AboutFont, AboutElements } from "./About.styled.js";

const About = (props) => {
  const seeProfiles = () => {
    alert("hre");
  };
  return (
    <AboutElements>
      About
      <AboutFont>About {props.profile.about_me}</AboutFont>
      <AboutFont>{props.profile.email}</AboutFont>
      <AboutFont>{props.profile.phone_number}</AboutFont>
    </AboutElements>
  );
};
export default About;
