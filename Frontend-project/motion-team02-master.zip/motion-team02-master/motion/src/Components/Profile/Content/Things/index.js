import { ThingsBox, FontTitle, ThingBox } from "./Things.styled";
import Thing from "./Thing";

const Things = (props) => {
  console.log("Thisnssssss");
  return (
    <ThingsBox>
      <FontTitle>Things I like</FontTitle>
      <ThingBox>
        {props.things
          ? props.things.map((thing, index) => {
              return <Thing key={index} index={index} thing={thing} />;
            })
          : ""}
      </ThingBox>
    </ThingsBox>
  );
};
export default Things;
