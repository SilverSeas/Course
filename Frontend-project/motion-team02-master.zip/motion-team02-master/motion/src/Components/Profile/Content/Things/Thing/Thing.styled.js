import styled from "styled-components";

export const FontThing = styled.li.attrs({ className: "FontThing" })`
  font-family: "Roboto";
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 16px;
  list-style-type: none;
  color: black;
`;

export const RoundRetangle = styled.div.attrs({ className: "RoundRetangle" })`
  mix-blend-mode: normal;
  background-color: rgba(0, 0, 0, 0.2);
  border: 1px solid transparent;
  border-radius: 20px;
  padding: 5px;
  margin: 5px;

  font-family: "Roboto";
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 16px;
  list-style-type: none;
  color: black;
`;
