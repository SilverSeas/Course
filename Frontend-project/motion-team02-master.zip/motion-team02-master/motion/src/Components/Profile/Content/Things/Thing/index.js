import styled from "styled-components";
import { FontThing, RoundRetangle } from "./Thing.styled";
const Thing = (props) => {
  return <RoundRetangle>{props.thing}</RoundRetangle>;
};
export default Thing;
