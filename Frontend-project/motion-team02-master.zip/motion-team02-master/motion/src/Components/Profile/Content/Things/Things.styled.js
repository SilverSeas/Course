import styled from "styled-components";

export const ThingsBox = styled.div.attrs({
  className: "ThingsBox",
})`
  display: flex;
  flex-direction: row;
  background-color: #ffffff;
  height: 100%;
  width: 30%;

  align-items: center;
  justify-content: center;
  flex-direction: column;
`;

export const FontTitle = styled.div.attrs({
  className: "FontTitle",
})`
  font-family: "Roboto";
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 16px;

  color: #000000;
`;

export const ThingBox = styled.div.attrs({ className: "ThingBox" })`
  display: flex;
  flex-direction: row;
  background-color: #ffffff;
  padding: 10px;
  justify-content: space-around;
  flex-direction: row;
`;