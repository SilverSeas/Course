import styled from "styled-components";

export const ContentBox = styled.div.attrs({
  className: "ContentBox",
})`
  display: flex;
  flex-direction: row;
  background-color: blue;
  height: 60%;
  width: 833px;
  align-items: flex-end;
  align-content: center;
  background-color: yellow;
`;
