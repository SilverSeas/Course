import styled from "styled-components";

export const AboutElements = styled.div.attrs({
  className: "AboutBox",
})`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  width: 70%;
  background-color: #FFFFFF;
`;

export const AboutFont = styled.h2`
  font-family: "Roboto";
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 26px;
  color: #000000;
`;
