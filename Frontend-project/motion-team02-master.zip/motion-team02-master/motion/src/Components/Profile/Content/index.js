import About from "./About";
import Things from "./Things";
import { ContentBox } from "./Content.styled";
const Content = (props) => {
  return (
    <ContentBox>
      <About profile={props.profile}></About>
      <Things things={props.profile.things_user_likes}></Things>
    </ContentBox>
  );
};
export default Content;
