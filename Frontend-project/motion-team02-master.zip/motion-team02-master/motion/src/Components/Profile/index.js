import SideProfile from "./SideProfile/index";
import { ProfileBox, M } from "./Profile.styled";

import Content from "./Content";
import { useSelector } from "react-redux";
import React, { useState, useEffect } from "react";
import Stats from "./Stats/index";
import { MotionToken } from "../../axios/index";
import Banner from "./Banner";
import axios from "axios";
import { ProfileStyle } from "../../pages/Profile/styled.Profile";

const Profile = () => {
  //const profile = useSelector((store) => store.userInfo.user);
  const [profile, setProfile] = useState({});

  const fetchData = async () => {
    let config = {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("access")}`,
        "Content-Type": "application/json",
      },
      url: `https://motion.propulsion-home.ch/backend/api/users/me`,
    };
    const result = await axios(config);

    setProfile(result.data);
  };
  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div>
      <ProfileStyle>
        <ProfileBox>
          <SideProfile profile={profile} />
          <M>
            <Content profile={profile} />
            <Stats profile={profile}></Stats>
          </M>
        </ProfileBox>
        <Banner></Banner>
      </ProfileStyle>
    </div>
  );
};

export default Profile;
