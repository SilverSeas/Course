import {
  StatsFont,
  NumberFont,
  StatsElements,
  StatElement,
} from "./Stats.styled";

const Stats = (props) => {
  return (
    <StatsElements>
      <StatElement>
        <NumberFont>{props.profile.amount_of_posts}</NumberFont>
        <StatsFont>Posts</StatsFont>
      </StatElement>

      <StatElement>
        <NumberFont>{props.profile.amount_of_likes}</NumberFont>
        <StatsFont>Likes</StatsFont>
      </StatElement>

      <StatElement>
        <NumberFont>{props.profile.amount_of_friends}</NumberFont>
        <StatsFont>Friends</StatsFont>
      </StatElement>

      <StatElement>
        <NumberFont>{props.profile.amount_of_followers}</NumberFont>
        <StatsFont>Followers</StatsFont>
      </StatElement>
      <StatElement>
        <NumberFont>{props.profile.amount_following}</NumberFont>
        <StatsFont>Following</StatsFont>
      </StatElement>
    </StatsElements>
  );
};

export default Stats;
