import styled from "styled-components";

export const StatsElements = styled.div`
  display: flex;
  background-color: #ffffff;
  height: 40%;
  width: 100%;
  justify-content: space-evenly;
  align-items: center;
  border-top: 1px solid rgba(0, 0, 0, 0.1);
`;

export const StatElement = styled.div`
  display: flex;
  background-color: white;
  flex-direction: column;
`;

export const NumberFont = styled.h2`
  font-family: "Roboto";
  font-style: normal;
  font-weight: 400;
  font-size: 24px;
  line-height: 28px;

  color: #000000;
`;

export const StatsFont = styled.h2`
  font-family: "Roboto";
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 19px;
  /* identical to box height */

  color: #000000;

  mix-blend-mode: normal;
  opacity: 0.5;
`;
