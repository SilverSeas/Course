import styled from "styled-components";
import img1 from "../../../assets/images/users/banner.png";

export const BannerElements = styled.div`
  position: relative;
  display: flex;
  background-size: cover;
  background-position: center;
  width: 99vw;
  height: 600px;
  border: 1px solid white;
  align-items: baseline;
  justify-content: flex-end;
  flex-direction: row;
`;

export const Img = styled.img.attrs({
  src: `${img1}`,
})`
  display: flex;
  justify-items: end;
  position: absolute;
  width: 1500px;
  height: 350px;
  max-width: 100%;
  z-index: 0;
`;

export const ButtonCamera = styled.button.attrs({
  className: "ButtonCamera",
})`
  position: absolute;
  gap: 10px;
  display: flex;
  flex-direction: row;
  background-color: transparent;
  background-repeat: no-repeat;
  border: none;
  cursor: pointer;
  overflow: hidden;
  outline: none;
  z-index: 1;
  margin-top: 150px;
  margin-right: 200px;
  font-size: 18px;
  line-height: 18px;

  color: #ffffff;
`;
