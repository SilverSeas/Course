import React from "react";
import { BsFillCameraFill } from "react-icons/bs";
import { IconContext } from "react-icons";
import { BannerElements, Img, ButtonCamera } from "./styled.Banner.js";

export default function Banner() {
  return (
    <BannerElements>
      <ButtonCamera>
        Update banner
        <IconContext.Provider value={{ color: "white", size: "26px" }}>
          <div>
            <BsFillCameraFill />
          </div>
        </IconContext.Provider>
      </ButtonCamera>
      <Img></Img>
    </BannerElements>
  );
}
