import React from 'react'
import { HeaderContainer, HeaderRight, Logo, LogoText, NavContainer, NavLinkHeader, UserPic } from './Header.styles'
import logoIcon from '../../assets/images/logo.png'
import navLinkFeed from '../../assets/images/posts_logo.png'
import navLinkFriends from '../../assets/svgs/icon-friends.svg'
import notificationBell from '../../assets/svgs/notification_bell.svg'
import { MenuButton } from '../FeedComponents/Post/Post.styles'
import { useSelector } from 'react-redux'
import { ProfilePic } from '../FeedComponents/NewPost/NewPost.styles'
import { NavLink } from 'react-router-dom'
import { useLocation } from 'react-router-dom'
import NotificationBell from './NotificationBell'


const Header = ({children}) => {

    const location = useLocation()
    console.log(location.pathname)

const userImg = useSelector((store)=>store.currentUser.user.avatar)

  return (
    <>
    {(location.pathname==='/login' || location.pathname==='/loginpage')?'': (
    <HeaderContainer>
        <Logo>
            <img src={logoIcon}/>
            <LogoText>Motion</LogoText>
        </Logo>
        <NavContainer>
        <NavLinkHeader
            to="/feed"
            // style={({ isActive }) =>
            //   isActive ? activeStyle : undefined
            // }
          >
            
          
            <img src={navLinkFeed}/> <p>Posts</p>
            </NavLinkHeader>
            <NavLinkHeader
            to="/findfriends">
            <img src={navLinkFriends}/><p>Find Friends</p>
            </NavLinkHeader>
        </NavContainer>
        <HeaderRight>
            <NotificationBell/>
            <NavLink
            to="/profile">
            <UserPic src={userImg}/>
            </NavLink>
            
            <menuitem/>
        </HeaderRight>
    </HeaderContainer>
    )}
    {children}
    </>
  )
}

export default Header