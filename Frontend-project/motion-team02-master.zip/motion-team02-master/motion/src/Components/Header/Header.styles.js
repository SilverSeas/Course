import styled from "styled-components";
import { NavLink } from "react-router-dom";

export const HeaderContainer = styled.div`
 height: 80px;
    background-color: #ffffff;
    border-bottom: $secondary-color;
    display: flex;
    
    align-items: center;
    border-bottom: $accent-color 2px solid;
    box-shadow: 0px 0px 1px rgba(0, 0, 0, 0.2), 0px 10px 20px rgba(0, 0, 0, 0.05);
    border: none; 
`
export const Logo = styled.div`
    display: flex;
        align-items: center;
        padding: 5px;
        width: 140px;
        // justify-self: flex-end;
        // min-width: 200px;
        padding-right: 9%;
        padding-left: 2%;
`

export const LogoText = styled.p`
    font-size: 22px;
    font-weight: 400;
    padding-left: 10px;
`

export const NavContainer = styled.div`
    display: flex;
        align-items: center;
        width: 530px;
        // padding:10%;
        justify-content: space-between;
        // margin-right: 50%;
`

export const HeaderRight = styled.div`
    display: flex;
        width: 100%;
        justify-content: flex-end;
`

export const UserPic = styled.img`
    margin-right: 20px;
    margin-left:20px;
    
    min-height: 65px;
        min-width:65px;
        max-height: 65px;
        max-width:65px;
        
  border-radius: 50%;
`

export const NavLinkHeader = styled(NavLink)`

display:flex;
height: 20px;
align-items: center;
text-decoration: none;
height:80px;

&:hover,
&:focus{
    color: blue;
    border-bottom: 2px solid black;
};
&:active{
    color: red;
    
};
p{
    margin-left: 7px;
}

`