import React, { useEffect, useState } from 'react'
import { MotionToken } from '../../../axios';
import { Bell } from './Bell.styles';
import bellGrey from '../../../assets/svgs/notification_bell.svg'
import bellPurple from '../../../assets/svgs/bell_purple.svg'


const NotificationBell = () => {

    const [pending,setPending] = useState(0)

    const userData = async () => {
        let userT = await MotionToken("social/friends/requests");
        setPending(userT.data.results.filter(request => request.status === 'P'))
        
        
      };

      useEffect(()=>{
        userData()
      },[])

  return (<>
  <Bell src={pending.length?bellPurple:bellGrey}></Bell>
  {/* <Bell src={bellGrey}></Bell> */}
    <div>{pending.length}</div>
    </>
  )
}

export default NotificationBell