import styled from "styled-components";

export const Bell = styled.img`

`