import styled from 'styled-components';

export const Bar = styled.div`
        display: flex;
        justify-content: center;
        padding-left: 5%;
        padding-right: 5%;
        height:80px;
        border-bottom: 0.5px solid lightgray;
        background-color: #F2F2F2;
        


    `

export const BarWrapper = styled.div`
    display:flex;
        justify-content: space-between;
        align-items: center;
        width: 1200px;
        height:100%;
`

export const SearchFilter = styled.div`
font-family: 'Roboto';
font-style: normal;
font-weight: 400;
font-size: 16px;
line-height: 19px;



color: #000000;

mix-blend-mode: normal;
opacity: 0.5;


`

export const SearchFilterActive = styled.div`
font-family: 'Roboto';
font-style: normal;
font-weight: 400;
font-size: 16px;
line-height: 19px;
height:100%;
border-bottom: 2px solid;
display: flex;
align-items: center;
`

export const Filters = styled.div`
    display:flex;
    justify-content: space-between;
    align-items: center;
    width: 20%;
    height:100%;


`

export const Search = styled.div`
    display:flex;
    justify-content: flex-start;
    flex-grow: 1;


`

export const SearchIcon = styled.img`
  min-height: 20px;
  max-height: 20px;
  min-width: 20px;
  max-height: 20px;
  align-self: center;
`
export const SearchInput = styled.input`
        margin-left:35px;
        background-color: white;
        flex-grow: 1;
        background-color: transparent;
    border: none;
    padding-left: 10px;
    &:focus{
        outline: none;
    }
`

