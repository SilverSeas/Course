import React from "react";
import { useState } from "react";
import { Bar, BarWrapper, SearchFilterActive, SearchIcon, SearchInput } from "./SearchBar.styles";
import { SearchFilter, Filters, Search } from "./SearchBar.styles";
import searchIcon from  '../../assets/svgs/search_icon.svg'


export default function SearchBarClean(props) {

  
  const [searchText, setSearchText] = useState('')

  const searchHandler =(e)=>{
    e.preventDefault()
    props.setFetchSource('?search='+searchText)
  }
  
  return (
    <>
      <Bar>
        <BarWrapper>
        <Search>
          <SearchIcon src={searchIcon} alt="search_icon"/>
          <form onSubmit={(e)=>searchHandler(e)}>
            <SearchInput type="text" value={searchText} onChange={(e)=>setSearchText(e.target.value)} placeholder="Search posts..."/>
          </form>
        </Search>
        <Filters>
        {props.fetchSource==='likes/'?<SearchFilterActive>Liked</SearchFilterActive>:<SearchFilter onClick={()=>props.setFetchSource('likes/')}>Liked</SearchFilter>}
        {props.fetchSource==='friends/'?<SearchFilterActive>Friends</SearchFilterActive>:<SearchFilter onClick={()=>props.setFetchSource('friends/')}>Friends</SearchFilter>}
        {props.fetchSource==='following/'?<SearchFilterActive>Follow</SearchFilterActive>:<SearchFilter onClick={()=>props.setFetchSource('following/')}>Follow</SearchFilter>}
        </Filters>
        </BarWrapper>
      </Bar>
      
    </>
  );
}
