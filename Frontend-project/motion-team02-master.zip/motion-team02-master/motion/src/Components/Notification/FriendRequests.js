// FriendRequest.js
import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { MotionToken } from '../../axios/index';
import ProfilePreview from '../Notification/ProfilePreview';

const FriendRequests = () => {
  const [receivedRequests, setReceivedRequests] = useState([]);
  const [sentRequests, setSentRequests] = useState([]);

  useEffect(() => {
    const getFriendRequests = async () => {
      try {
        const response = await MotionToken.get('/social/friends/requests/');
        let user = await MotionToken("users/me/");
        console.log(user)
        setReceivedRequests(          
          response.data.results.filter(
            (request) => request.status === "P" && request.receiver.id === user.data.id
          )
            /*
            request.logged_in_user_received_fr === true &&
            !request.logged_in_user_is_friends &&
            !request.logged_in_user_is_rejected
          )
          */
        );
        setSentRequests(
          response.data.results.filter(
            (request) => request.status === "P" && request.requester.id === user.data.id
          )
          /*
          response.data.results.filter(
            (request) =>
              request.logged_in_user_sent_fr === true &&
              !request.logged_in_user_is_friends &&
              !request.logged_in_user_is_rejected
             
          )
          */
        );
      } catch (error) {
        console.log(error);
      }
    };
    
    getFriendRequests();
  }, []);

  const acceptRequest = async (friendId) => {
    try {
      const response = await MotionToken.patch(
        `/social/friends/requests/${friendId}/`, {
            "status": "A"
          }
      );
      setReceivedRequests(
        receivedRequests.filter((request) => request.id !== friendId)
      );
    } catch (error) {
      console.log(error);
    }
  };

  const rejectRequest = async (friendId) => {
    try {
      const response = await MotionToken.patch(
        `/social/friends/requests/${friendId}/`, {
          "status": "R"
        }
      );
      setReceivedRequests(
        receivedRequests.filter((request) => request.id !== friendId)
      );
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <Container>
      <Section>
        <Title>Received Requests</Title>
        {receivedRequests.length === 0 ? (
          <NoRequests>no open requests</NoRequests>
        ) : (
          <ProfilesWrapper>
            {receivedRequests.map((profile) => (
              <ProfilePreview key={profile.id} type="received" profile={profile} acceptRequest={acceptRequest} rejectRequest={rejectRequest}/>
            ))}
          </ProfilesWrapper>
        )}
      </Section>

      <Section>
        <Title>Sent Requests</Title>
        {sentRequests.length === 0 ? (
          <NoRequests>no pending requests</NoRequests>
        ) : (
          <ProfilesWrapper>
            {sentRequests.map((profile) => (
              <ProfilePreview key={profile.id} type="sent" profile={profile} />
            ))}
          </ProfilesWrapper>
        )}
      </Section>
    </Container>
  );
};

export default FriendRequests;


const Container = styled.div`
  background-color: #fff;
  padding: 10px;
  border: 1px solid #ddd;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  width: 360px;
  left: 0px;
  top: 0px;
  border-radius: 4px;
`;


const Section = styled.div`
  margin-bottom: 24px;
`;

const Title = styled.h2`
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 16px;
`;

const ProfilesWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
`;

const NoRequests = styled.p`
  margin: 16px 0;
  text-align: center;
  color: gray;
`;
