import styled from "styled-components";

export default function ProfilePreview({ profile, type, acceptRequest, rejectRequest }) {


  return (
    <ProfileCardContainer>
       {type === "received" ? (
        <div className="box">
            <img src={profile.requester.avatar} alt={profile.requester.first_name + ' ' + profile.requester.last_name} />
            <div className="innerBox">
                <h3>{profile.requester.first_name} {profile.requester.last_name}</h3>
                {profile.requester.location ? (
                  <h5>{profile.requester.location}</h5>
                ) : ''}
            </div>
            <div className="buttons-container">
                <AcceptButton onClick={() => acceptRequest(profile.id)}>A</AcceptButton>
                <RejectButton onClick={() => rejectRequest(profile.id)}>R</RejectButton>
            </div>
        </div>
       ) : (
        <div className="box">
            <img src={profile.receiver.avatar} alt={profile.receiver.first_name + ' ' + profile.requester.last_name} />
            <div className="innerBox">
                <h3>{profile.receiver.first_name} {profile.receiver.last_name}</h3>
                {profile.receiver.location ? (
                  <h5>{profile.receiver.location}</h5>
                ) : ''}
            </div>
            <div className="buttons-container">
                <Pending/>
            </div>
        </div>

       )}
    </ProfileCardContainer>
  );
}

const ProfileCardContainer = styled.div`
  .box {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background-color: #fff;
    padding: 10px;
    border: 1px solid #ddd;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    width: 340px;
    left: 0px;
    top: 0px;
    border-radius: 4px;
  }

  .innerBox {
    width:450px;
  }

  img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
  }

  h3 {
    font-family: Roboto;
    font-size: 16px;
    font-weight: 400;
    line-height: 25.78px;
    text-align: center;
    margin-bottom: 0px;
  }

  h5 {
    font-family: Roboto;
    font-size: 14px;
    font-weight: 400;
    line-height: 24px;
    text-align: center;
    color: rgba(0, 0, 0, 0.5);
    line-height: 16.41px;
    justify-content: flex-start;
    margin-top: 0px;
  }

  h6 {
    font-family: Roboto;
    font-size: 14px;
    font-weight: 400;
    line-height: 24px;
    text-align: center;
    justify-content: flex-start;
    width: 282px;
    line-height: 16.41px;
  }

  .buttons-container {
    display: flex;
    justify-content: flex-end;
    width: 100%;
  
  }

  button:first-child {
    margin-right: 20px;
  }

  button:last-child {
    margin-left: 20px;
  }
`;
const Pending = styled.button`
  margin-top: 16px;
  font-size: 12px;
  border: none;
  height: 40px;
  width: 40px;
  border-radius: 30px;
  background-color: lightgrey;
  color: #fff;
`;

const AcceptButton = styled.button`
  margin-top: 16px;
  font-size: 12px;
  border: none;
  height: 40px;
  width: 40px;
  border-radius: 30px;
  background-image: linear-gradient(132.96deg, #C468FF 3.32%, #6E91F6 100%);
  color: #fff;
`  
const RejectButton = styled.button`
  margin-top: 16px;
  font-size: 12px;
  border: none;
  height: 40px;
  width: 40px;
  border-radius: 30px;
  background-color: lightgrey;
  color: #fff;
`;
