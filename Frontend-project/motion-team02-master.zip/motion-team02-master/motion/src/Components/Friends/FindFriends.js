import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import ProfileCard from "./ProfileCard";
import styled from "styled-components";

import { MotionToken } from "../../axios";
import { addUsers } from "../../redux/slices/profile";

export default function FindFriends() {
  const [profiles, setProfiles] = useState([]);

  useEffect(() => {
    // async function getData() {
    //   try {
    //     let response = await MotionToken("users/?limit=6");
    //     if (res.status == 200) {
    //       console.log("Result Status:", response.results);
    //     }
    //     // Don't forget to return something
    //     return res.data;
    //   } catch (err) {
    //     console.error(err);
    //   }
    // }

    const fetchData = async () => {
      const response = await MotionToken("users/?limit=6");
      console.log("Result from request: ", response.data.results);
      addUsers(response.data.results)
      setProfiles(response.results);
    };
    fetchData();
    console.log("Profiles", profiles);

  }, []);

  return (
    <div className="Friends">
      <ProfilesGrid>
        {/* {profiles
          ? profiles.map((profile, index) => {
              return (
                <ProfileCard key={index} index={index} profile={profile} />
              );
            })
          : ""} */}
      </ProfilesGrid>
    </div>
  );
}

//styling

const ProfilesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-gap: 16px;
  margin: 50px;
`;
