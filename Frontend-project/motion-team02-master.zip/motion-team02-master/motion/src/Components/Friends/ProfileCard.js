import styled from "styled-components";
import { useDispatch } from "react-redux";
import { addFriend, follow } from "../../redux/slices/profile";

export default function ProfileCard({ profile }) {
  const dispatch = useDispatch();

  const friendButtonText = profile.logged_in_user_is_friends
    ? "Friends"
    : "Add Friend";

  const friendButtonStyle = profile.logged_in_user_is_friends
    ? {
        backgroundImage:
          "linear-gradient(132.96deg, #C468FF 3.32%, #6E91F6 100%)",
      }
    : { backgroundColor: "rgba(0, 0, 0, 0.2)" };
  const followButtonText = profile.logged_in_user_is_following
    ? "Following"
    : "Follow";
  const followButtonStyle = profile.logged_in_user_is_following
    ? {
        backgroundImage:
          "linear-gradient(132.96deg, #C468FF 3.32%, #6E91F6 100%)",
      }
    : { backgroundColor: "rgba(0, 0, 0, 0.2)" };

  return (
    <ProfileCardContainer>
      <img
        src={profile.avatar ? profile.avatar : ""}
        alt={profile.first_name ? profile.first_name : ""}
      />
      <h3>{profile.first_name ? profile.first_name : ""}</h3>
      <h5>{profile.location}</h5>
      <div className="buttons-container">
        <button
          onClick={() => dispatch(addFriend(profile))}
          style={friendButtonStyle}
        >
          {friendButtonText}
        </button>
        <button
          onClick={() => dispatch(follow(profile))}
          style={followButtonStyle}
        >
          {followButtonText}
        </button>
      </div>
      <h6>{profile.bio}</h6>
      <div className="tags">
        {profile.things_user_likes.map((tag) => (
          <Tag key={tag}>{tag}</Tag>
        ))}
      </div>
    </ProfileCardContainer>
  );
}

const ProfileCardContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  background-color: #fff;
  padding: 10px;
  border: 1px solid #ddd;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  height: 489px;
  width: 362px;
  left: 0px;
  top: 0px;
  border-radius: 4px;

  img {
    width: 90px;
    height: 91px;
    border-radius: 50%;
  }

  h3 {
    font-family: Roboto;
    font-size: 22px;
    font-weight: 400;
    line-height: 25.78px;
    text-align: center;
    width: 282px;
    margin-bottom: 0px;
  }

  h5 {
    font-family: Roboto;
    font-size: 14px;
    font-weight: 400;
    line-height: 24px;
    text-align: center;
    width: 282px;
    line-height: 16.41px;
    margin-top: 0px;
  }

  h6 {
    font-family: Roboto;
    font-size: 14px;
    font-weight: 400;
    line-height: 24px;
    text-align: center;
    width: 282px;
    line-height: 16.41px;
  }

  .buttons-container {
    display: flex;
    justify-content: center;
    width: 100%;
  }

  button:first-child {
    margin-right: 20px;
  }

  button:last-child {
    margin-left: 20px;
  }

  button {
    margin-top: 16px;
    font-size: 12px;
    border: 1px solid rgba(0, 0, 0, 0.2);
    height: 40px;
    width: 130px;
    border-radius: 30px;
    background-color: rgba(0, 0, 0, 0.2);
    color: #fff;

    cursor: pointer;

    &:hover {
      filter: drop-shadow(0px 10px 20px rgba(0, 0, 0, 0.2));
    }
  }

  .tags {
    display: flex;
    flex-wrap: wrap;
    margin-top: 16px;
    font-family: Roboto;
    font-size: 14px;
    height: 100px;
    justify-content: flex-start;
    align-items: center;
  }
`;
const Tag = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  color: black;
  padding-left: 19.28%;
  padding-right: 18.07%;
  background-color: rgba(0, 0, 0, 0.05);
  mix-blend-mode: normal;
  border-radius: 18px;
  margin: 10px;
  height: 16px;
`;
