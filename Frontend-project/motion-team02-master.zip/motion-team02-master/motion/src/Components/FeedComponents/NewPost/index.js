import React from 'react'
import { SendPost, ProfilePic, NewPostContainer, NewPostInput, NewPostInputDetail, Cancel } from './NewPost.styles'
import {useState} from 'react'
import img1 from './send_button.png'
import axios from "axios";
import { MotionToken } from '../../../axios';
import jennifer from '../../../assets/images/users/jennifer.png'
import PostDetailView from '../PostDetailView';
import { ModalContainer  } from '../DeleteModal/Modal.styles';
import { ModalContentRight, PostPictureSingleDetail, ModalContent, NewPostModalTextContainer } from '../PostDetailView/PostDetailView.styles';



const NewPost = (props) => {

    const [previewImage, setPreviewImage] = useState(undefined);
    const [files,setFiles] = useState([])
    const [textContent, setTextContent] = useState('')
    const formData = new FormData();
    
    // formData.append('content', 'textContent');


   const onFileChange=(e)=> {
    // console.log(e.target.files)
    
    // for (let i = 0; i < e.target.files.length; i++) {
    //     formData.append('images', e.target.files[i]);
        
    // }
    // console.log(pics)
        setFiles(e.target.files[0]);
        // formData.append('images', files);
        // formData.append('content', 'textContent');
        setPreviewImage(URL.createObjectURL(e.target.files[0]));
    
        
    
        
    
      }

      const closeModal =()=>{

        setPreviewImage('')
      }







const sendPost = async (e)=>{

    

    formData.append('images', files);
        formData.append('content', textContent);

    

    let config = {
        headers: {
            'Content-Type': 'multipart/form-data'
        },
        method: 'post',
        maxBodyLength: Infinity,
        url: 'https://motion.propulsion-home.ch/backend/api/social/posts/',
        
        data: formData
      };

    let postResponse = await MotionToken(config)
    console.log(postResponse)
      setPreviewImage('')
    setTextContent('')
    props.setRefresh(!props.refresh)


}

  return (
    <NewPostContainer> 

    {/* <ProfilePic/> */}
    <ProfilePic src={props.avatar}/>
    <NewPostInput placeholder={'whats on your mind '+props.name} value={textContent} onChange={(e)=>setTextContent(e.target.value)}></NewPostInput>
    <input onChange={onFileChange} type='file' id="files" name="files" />
    {previewImage?
    <ModalContainer>
      <ModalContent><PostPictureSingleDetail className='preview' src={previewImage}/>
      <ModalContentRight>
        <NewPostModalTextContainer>
          <NewPostInputDetail placeholder={'whats on your mind '+props.name} value={textContent} onChange={(e)=>setTextContent(e.target.value)}></NewPostInputDetail>
          <SendPost onClick={()=>sendPost()}><img src={img1}/></SendPost>
          <Cancel onClick={()=>closeModal()}>X</Cancel>
        </NewPostModalTextContainer>
        </ModalContentRight>
        </ModalContent>
    </ModalContainer>  :''
  
  }
    
    <SendPost onClick={()=>sendPost()}><img src={img1}/></SendPost>
    </NewPostContainer>
  )
}

export default NewPost