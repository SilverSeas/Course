import styled from 'styled-components';

export const SendPost = styled.button`
  display: flex;
        align-items: center;
        
        height:60px;
        width: 60px;
        border-radius: 50%;
        background: linear-gradient(132.96deg, #C468FF 3.32%, #6E91F6 100%);
        box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.07);
        border: none;
        margin-right: 3%;
        
        padding:20px;
        align-self: center;
        
`;

export const ProfilePic = styled.img`

margin-left: 30px;
        min-height: 65px;
        min-width:65px;
        max-height: 65px;
        max-width:65px;
        
  border-radius: 50%;
  
  
`;

export const NewPostContainer = styled.span`
box-shadow: 0px 0px 1px rgba(0, 0, 0, 0.2), 0px 10px 20px rgba(0, 0, 0, 0.05);
    border-radius: 4px;
    background-color: #ffffff;
    margin-top: 16px;
    margin-bottom: 16px;
/* border: 1px solid; */
    width: 100%;
    min-height: 120px;
    display: flex;
    justify-content: flex-start;
    // padding-right: 10px;
    align-items: center;
    /* padding-top:10px; */
    /* padding-bottom:10px; */

    .preview{
        max-width: 100%;
        max-height:100%;
    }

`
export const NewPostInput = styled.input`
        margin-left:35px;
        background-color: white;
        flex-grow: 1;
        /* background-color: $background-color; */
    border: none;
    padding-left: 10px;
    &:focus{
        outline: none;
    }
`

export const NewPostInputDetail = styled.textarea`
        margin-left:35px;
        background-color: white;
        flex-grow: 1;
        /* background-color: $background-color; */
    border: none;
    padding-left: 10px;
    &:focus{
        outline: none;
    }
`

export const Cancel = styled.button`
position:relative;
background-color: transparent;
border: none;
left:70px;
top:-50px;
color:red;





`