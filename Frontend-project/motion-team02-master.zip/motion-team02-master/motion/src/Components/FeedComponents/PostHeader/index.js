import React from 'react'

import DeleteModal from '../DeleteModal';


import {MenuOpener, Menu, PostContainer, PostFooterIcon, PostContent, PosterImg, PosterName, PostFooter, PostFooterIcons, PostFooterLikes, PostHeader,PostMeta,PostPicture,PostPictures,PostText, PostTime, LikeButton, ShareButton, MenuWrapper, MenuButton, ButtonWrapper, MenuIcons, PostFooterIconLiked } from '../Post/Post.styles';
import { time } from '../../../Helpers/functions';
import  menuIcon  from '../../../assets/svgs/menu.svg'
import  shareIcon  from '../../../assets/svgs/share.svg'
import  likeIcon  from '../../../assets/svgs/heart.svg'
import  likeIconPurple  from '../../../assets/svgs/heartPurple.svg'
import  editIcon  from '../../../assets/svgs/edit.svg'
import  trashIcon  from '../../../assets/svgs/trash.svg'
import { useState } from 'react';

const PostHeaders = (props) => {

    const [showMenu,setShowMenu] = useState(false)
    
    const [showDeleteModal,setShowDeleteModal] =useState(false)

    const openMenu =()=>{
        setShowMenu(!showMenu)
    }

    const deleteHandler =()=>{
        setShowDeleteModal(true)
        setShowMenu(false)
    }

    const openPostDetail=()=>{
        props.setShowPostDetail(true)
        setShowMenu(false)
    }

    const date = new Date(props.pos?.created) 
    
    
    let postTime =time(date)

    

  return (<>
  {showDeleteModal?<DeleteModal show={setShowDeleteModal} id={props.pos?.id} setRefresh={props.setRefresh} refresh={props.refresh} text={'Are you sure you want to delete the post?'}/>:''}
  <PostHeader>
    <PosterImg src={props.pos?.user.avatar}></PosterImg>
            <PostMeta>
                <PosterName>{props.pos?.user.first_name}</PosterName>
                <PostTime>{postTime}</PostTime>
            </PostMeta>
            <MenuWrapper >
                <MenuOpener onClick={openMenu}>
                    <Menu src={menuIcon}  />
                </MenuOpener>
                {showMenu?<ButtonWrapper>
                    <MenuButton onClick={()=>openPostDetail()}><MenuIcons src={editIcon}/>Edit</MenuButton>
                    <MenuButton onClick={()=>deleteHandler()}><MenuIcons src={trashIcon}/>Delete</MenuButton>
                </ButtonWrapper>:''}
                
            </MenuWrapper>
            </PostHeader>
            {/* <Menu src={menuIcon} /> {showMenu?<Modal/>:''} */}
  </>
    
  )
}

export default PostHeaders