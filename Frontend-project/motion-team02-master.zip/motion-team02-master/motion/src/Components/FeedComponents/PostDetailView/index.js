import React from 'react'
import { ModalContainer } from '../DeleteModal/Modal.styles'

import { DetailPictureCon, ModalContent, ModalContentRight, PostPictureSingleDetail } from './PostDetailView.styles'
import {MenuOpener, Menu, PostContainer, PostFooterIcon, PostContent, PosterImg, PosterName, PostFooter, PostFooterIcons, PostFooterLikes, PostHeader,PostMeta,PostPicture,PostPictures,PostText, PostTime, LikeButton, ShareButton, MenuWrapper, MenuButton, ButtonWrapper, MenuIcons, PostFooterIconLiked } from '../Post/Post.styles';
import { time } from '../../../Helpers/functions';
import  menuIcon  from '../../../assets/svgs/menu.svg'
import  shareIcon  from '../../../assets/svgs/share.svg'
import  likeIcon  from '../../../assets/svgs/heart.svg'
import  likeIconPurple  from '../../../assets/svgs/heartPurple.svg'
import  editIcon  from '../../../assets/svgs/edit.svg'
import  trashIcon  from '../../../assets/svgs/trash.svg'
import { useState } from 'react';
import PostHeaders from '../PostHeader';
import { PostPictureSingle } from '../Post/Post.styles';
import { MotionToken } from '../../../axios';
import { Cancel } from '../NewPost/NewPost.styles';


const PostDetailView = (props) => {

    const [showMenu,setShowMenu] = useState(false)
    const [content,setContent] =useState(props.pos.content)
    
    const [showDeleteModal,setShowDeleteModal] =useState(false)

    const openMenu =()=>{
        setShowMenu(!showMenu)
    }

    const deleteHandler =()=>{
        setShowDeleteModal(true)
        setShowMenu(false)
    }

    const closeDetailView =()=>{
        props.show(false)
        
        

    }

    const date = new Date(props.pos?.created) 

    const editPost = async()=>{

        let config ={
            method:'patch',
            
            url:'social/posts/'+props.pos.id+'/',
            data: {
                content:content,
            }
        }
        
        let response = await MotionToken(config)
        props.setRefresh(!props.refresh)
        console.log(response)

    }
    
    
    let postTime =time(date)


  return (
    <ModalContainer>
        <ModalContent>
            <DetailPictureCon >

            <PostPictures>
        {props.pos?.images.length>1?props.pos?.images.map((image)=>{
                  return <div><PostPicture key={image.id} src={image.image}/></div>
                }):props.pos?.images.map((image)=>{
                    return <PostPictureSingleDetail key={image.id} src={image.image}/>
                  })}
            
            {/* <div><PostPicture src={mountain1}/></div>
            <div><PostPicture src={mountain2}/></div>
            <div><PostPicture src={mountain3}/></div>
            <div><PostPicture src={mountain4}/></div> */}
        </PostPictures>    
                
            </DetailPictureCon>
            <ModalContentRight>
                <PostHeaders pos={props.pos}  refresh={props.refresh} setRefresh={props.setRefresh}></PostHeaders>
                <textarea name="Text1" cols="40" rows="10" value={content} onChange={(e)=>(setContent(e.target.value))}></textarea>
                <button onClick={()=>editPost()}>Save</button>
                {/* <button onClick={()=>delete()}>delete Picture</button> */}
                <Cancel onClick={()=>closeDetailView()}>X</Cancel>
                {/* <button onClick={()=>closeDetailView()}>Close</button> */}
            </ModalContentRight>
        </ModalContent>
        
    </ModalContainer>
  )
}

export default PostDetailView