import styled from "styled-components"

export const DetailPictureCon = styled.div`
display:flex;

width: 70%;
height: 600px;

background-color: black;
box-shadow: 0px 0px 1px rgba(0, 0, 0, 0.2), 0px 10px 20px rgba(0, 0, 0, 0.05);
    border-radius: 4px;


`

export const ModalContent = styled.div`

width: 70%;
min-height: 500px;
/* left: 0; */
/* right: 0; */
/* top:0; */
/* 'bottom:0; */
background-color: white;
display:flex;
box-shadow: 0px 0px 1px rgba(0, 0, 0, 0.2), 0px 10px 20px rgba(0, 0, 0, 0.05);
    border-radius: 4px;



`
export const ModalContentRight = styled.div`


min-height: 100%;
min-width:400px;
display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding-right: 30px;
    padding-left: 30px;
    padding-top: 10px;
    padding-bottom: 0px;
    box-shadow: 0px 0px 1px rgba(0, 0, 0, 0.2), 0px 10px 20px rgba(0, 0, 0, 0.05);
    border-radius: 4px;
    background-color: #ffffff;
    /* margin-top: 16px; */
    /* margin-bottom: 16px; */

/* background-color: green; */



`

export const PostPictureSingleDetail = styled.img`
        height: 100%; 
/* height: 240px;  */
object-fit: contain;
overflow: hidden;
        display: block;
        border-radius: 5%;
        align-self: center;
`

export const NewPostModalTextContainer =styled.div`
display:flex;
/* flex-direction: row; */


`