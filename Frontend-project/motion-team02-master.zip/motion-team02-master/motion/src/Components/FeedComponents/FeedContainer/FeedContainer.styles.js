
import styled from 'styled-components'





export   const FeedContainer = styled.div`
    display:flex;
    width: 100vw;
    /* max-width: 1200px; */
    min-height: 100%;
    height: fit-content;
    /* border: solid 1px; */
    align-self: center;
    flex-direction: column;
    background-color: #F2F2F2;

    `
export const PostContainer = styled.div`
 display:flex;
    width: 85%;
    max-width: 1200px;
    height: 100%;
    /* border: solid 1px; */
    align-self: center;
    flex-direction: column;
    flex-direction: row;

    `
export const PostContainerRight = styled.div`
    display:flex;
    flex-direction: column;
    width:50%;
    
    margin-left: 16px;
    margin-top:16px;

`

export const PostContainerLeft = styled.div`
    display:flex;
    flex-direction: column;
    width:50%;
    
    margin-top:16px;
    margin-right: 16px;

`

 

