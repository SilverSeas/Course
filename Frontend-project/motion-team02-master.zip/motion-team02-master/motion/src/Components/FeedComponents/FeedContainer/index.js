import React from 'react'
import { MotionToken } from '../../../axios'
import axios from 'axios'
import { useEffect, useState } from 'react'
import SearchBarClean from '../../SearchBar/SearchBarClean'
import NewPost from '../NewPost'
import Post from '../Post'
import { useLocation } from 'react-router-dom'
import { FeedContainer, PostContainer, PostContainerLeft, PostContainerRight } from './FeedContainer.styles'


const FeedContainerComponent = () => {

    const [user, setUser] = useState()
//   const [searchText, setSearchText] = useState('')
  const [posts, setPosts] = useState([])
  const [postsLeft, setPostsLeft] = useState([])
  const [postsRight, setPostsRight] = useState([])
  const [refresh, setRefresh] =useState(false)
  const [fetchSource,setFetchSource] =useState('me/')
  
 
    const location = useLocation()
    console.log(location.pathname)
     
  
  
  const userData = async () => {

    let config = {
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('access')}`,
        'Content-Type': 'application/json'
        },
        url: `https://motion.propulsion-home.ch/backend/api/users/me`
        
    
    }
    let userT = await MotionToken('users/me');
    setUser(userT)
    // console.log(user.data.first_name);
  };

  

  

  

  useEffect(()=>{
    const myPosts = async () => {
      console.log(`social/posts/${fetchSource}`)
      let config = {
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('access')}`,
        'Content-Type': 'application/json'
        },
        
        
        url: `https://motion.propulsion-home.ch/backend/api/social/posts/${fetchSource}`
      };
      let postsFetched = await axios(config);
      setPosts(postsFetched.data.results)
        console.log(fetchSource)
      setPostsLeft(postsFetched.data.results.slice(0,postsFetched.data.results.length/2))
    //   console.log(postsLeft)
      setPostsRight(postsFetched.data.results.slice(postsFetched.data.results.length/2))
      // console.log(postsRight)
      console.log(postsFetched.data.results);
    };

    userData();
    myPosts()

  },[fetchSource, refresh])


  return (<>
    {location.pathname==='/feed'?<SearchBarClean fetchSource={fetchSource} setFetchSource={setFetchSource}></SearchBarClean>:''}
    <FeedContainer>
        <PostContainer>
                <PostContainerLeft>
                {location.pathname==='/feed'?<NewPost refresh={refresh} setRefresh={setRefresh} name={user?.data.first_name} avatar={user?.data.avatar}/>:''}
                    {/* <NewPost name='Patrizia'/> */}
                    {postsLeft.map((post)=>{
                      return <Post key={post.id} pos={post} refresh={refresh} setRefresh={setRefresh}/>
                    })}

                </PostContainerLeft>
                <PostContainerRight>
                {postsRight.map((post)=>{
                      return <Post key={post.id} pos={post} refresh={refresh} setRefresh={setRefresh}/>
                    })}
                </PostContainerRight>
            </PostContainer>
        </FeedContainer>
        </>
  )
}

export default FeedContainerComponent