import styled from "styled-components";

export const ModalContainer = styled.div`

    position: fixed;
    display:flex;
    justify-content: center;
    align-items: center;
    left: 0;
    right: 0;
    top:0;
    bottom:0;
    background-color: rgba(0,0,0,0.5);
    z-index: 1;
    box-shadow: 0px 0px 1px rgba(0, 0, 0, 0.2), 0px 10px 20px rgba(0, 0, 0, 0.05);
    border-radius: 4px;
    
    `

export const ModalContent = styled.div`

width: 800px;
min-height: 500px;
/* left: 0; */
/* right: 0; */
/* top:0; */
/* 'bottom:0; */
background-color: white;


`

