import React from 'react'
import { ModalContainer,ModalContent } from './Modal.styles'
import { MotionToken } from '../../../axios';

const DeleteModal = (props) => {

  const deleteFetch =async ()=>{

    let config = {
      url: '/social/posts/'+props.id+'/',
      method: 'delete'}

      let response = await MotionToken(config)
      if (response.status===204) {
        props.show(false)
      props.setRefresh(!props.refresh)

      }
    


  }


  return (
    <ModalContainer>
        <ModalContent>
            {props.text}
            <button onClick={()=>deleteFetch()}>Yes</button>
            <button onClick={()=>props.show(false)}>Cancel</button>
        </ModalContent>
        <button></button>
    </ModalContainer>
  )
}

export default DeleteModal