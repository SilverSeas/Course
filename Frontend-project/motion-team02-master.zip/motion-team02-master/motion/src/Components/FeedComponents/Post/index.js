import React, { useState } from 'react'
import {MenuOpener, Menu, PostContainer, PostFooterIcon, PostContent, PosterImg, PosterName, PostFooter, PostFooterIcons, PostFooterLikes, PostHeader,PostMeta,PostPicture,PostPictures,PostText, PostTime, LikeButton, ShareButton, MenuWrapper, MenuButton, ButtonWrapper, MenuIcons, PostFooterIconLiked } from './Post.styles';
import  menuIcon  from '../../../assets/svgs/menu.svg'
import  shareIcon  from '../../../assets/svgs/share.svg'
import  likeIcon  from '../../../assets/svgs/heart.svg'
import  likeIconPurple  from '../../../assets/svgs/heartPurple.svg'
import  editIcon  from '../../../assets/svgs/edit.svg'
import  trashIcon  from '../../../assets/svgs/trash.svg'
import DeleteModal from '../DeleteModal';
import { PostPictureSingle } from './Post.styles';
import { MotionToken } from '../../../axios';
import mountain1 from '../../../assets/images/feedPics/image1.png'
import mountain2 from '../../../assets/images/feedPics/image2.png'
import mountain3 from '../../../assets/images/feedPics/image3.png'
import mountain4 from '../../../assets/images/feedPics/image4.png'
import PostDetailView from '../PostDetailView';
import { time } from '../../../Helpers/functions';
import PostHeaders from '../PostHeader';


const Post = (props) => {

    const [showMenu,setShowMenu] = useState(false)
    const [showPostDetail,setShowPostDetail] = useState(false)
    const [showDeleteModal,setShowDeleteModal] =useState(false)

    let isLiked =props.pos?.logged_in_user_liked

    const date = new Date(props.pos?.created) 
    
    
    let postTime =time(date)

    
    
    




    const openMenu =()=>{
        setShowMenu(!showMenu)
    }

    const deleteHandler =()=>{
        setShowDeleteModal(true)
        setShowMenu(false)
    }

    
    const likeHandler = async ()=>{

        let config = {
            url: 'social/posts/toggle-like/'+props.pos?.id+'/',
            method: 'post'}
      
            let response = await MotionToken(config)
            console.log(response)
            if (response.status===200) {
              
            props.setRefresh(!props.refresh)
      
            }

    }
    


  return (
    <>
    
    {showPostDetail?<PostDetailView show={setShowPostDetail} pos={props.pos} setRefresh={props.setRefresh} refresh={props.refresh}/>:''}
    <PostContainer >
        {/* <PostHeader>
            <PosterImg src={props.pos?.user.avatar}></PosterImg>
            <PostMeta>
                <PosterName>{props.pos?.user.first_name}</PosterName>
                <PostTime>{postTime}</PostTime>
            </PostMeta>
            <MenuWrapper >
                <MenuOpener onClick={openMenu}>
                    <Menu src={menuIcon}  />
                </MenuOpener>
                {showMenu?<ButtonWrapper>
                    <MenuButton><MenuIcons src={editIcon}/>Edit</MenuButton>
                    <MenuButton onClick={()=>deleteHandler()}><MenuIcons src={trashIcon}/>Delete</MenuButton>
                </ButtonWrapper>:''}
                
            </MenuWrapper>
            {/* <Menu src={menuIcon} /> {showMenu?<Modal/>:''} */}
        {/* </PostHeader> */} 
        <PostHeaders pos={props.pos} setShowPostDetail={setShowPostDetail} refresh={props.refresh} setRefresh={props.setRefresh}/>
        
        <PostText >{props.pos?.content}
        </PostText>
        <PostPictures>
        {props.pos?.images.length>1?props.pos?.images.map((image)=>{
                  return <div><PostPicture key={image.id} src={image.image}/></div>
                }):props.pos?.images.map((image)=>{
                    return <div><PostPictureSingle key={image.id} src={image.image}/></div>
                  })}
            
            {/* <div><PostPicture src={mountain1}/></div>
            <div><PostPicture src={mountain2}/></div>
            <div><PostPicture src={mountain3}/></div>
            <div><PostPicture src={mountain4}/></div> */}
        </PostPictures>
        <PostFooter>
            <PostFooterIcons>
                <LikeButton onClick={()=>likeHandler()}>{isLiked?<PostFooterIconLiked src={likeIconPurple}/>:<PostFooterIcon src={likeIcon}/>}Like</LikeButton>
                <ShareButton><PostFooterIcon src={shareIcon}/>Share</ShareButton>
            </PostFooterIcons>
            <PostFooterLikes>
                {props.pos?.amount_of_likes +' Likes'}
            </PostFooterLikes>
        </PostFooter>
        
    
    </PostContainer>
    </>
  )
}

export default Post