import styled from "styled-components";

export const PostContainer = styled.div`

border: $border_default;
     /* width: 100%; */
    // height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding-right: 30px;
    padding-left: 30px;
    padding-top: 10px;
    padding-bottom: 0px;
    box-shadow: 0px 0px 1px rgba(0, 0, 0, 0.2), 0px 10px 20px rgba(0, 0, 0, 0.05);
    border-radius: 4px;
    background-color: #ffffff;
    margin-top: 16px;
    margin-bottom: 16px;
    
  
`
export const MenuWrapper = styled.div`

 position: absolute; 
 top:30px;
 right: -110px;
 width: 120px;
 height:fit-content;
 /* border: solid 1px; */
 display:flex;
 flex-direction: column;
 align-items: flex-start;
 gap:6px;
`

export const MenuOpener = styled.div`

 
 height:fit-content;
 /* border: solid 1px; */
 display:flex;
 flex-direction: column;
 
 align-items: flex-start;
 padding-left: 5px;
 width:20%;
 
`

export const Menu = styled.img`
        height:15px;
        
  
`

export const MenuButton = styled.button`
height: 35px;
  width:100%;
  background-color: white;
  border: none;
  :hover{
        background-color: lightgray;
  }
`

export const ButtonWrapper = styled.div`

  width:100%;
  background-color: white;
  box-shadow: 0px 0px 1px rgba(0, 0, 0, 0.2), 0px 10px 20px rgba(0, 0, 0, 0.05);
`




export const PostHeader = styled.div`
display:flex;
    flex-direction: row;
    justify-content: flex-start;
    // padding-left: 30px;
    position: relative; 
    
    
    align-items: center;
    border: $border_default;
    font-weight: 400;
        font-size: 14px;
        height: 80px;
       
        /* border: solid 1px; */

`

export const PostTime = styled.p`

font-family: 'Roboto';
font-style: normal;
font-weight: 400;
font-size: 14px;
line-height: 16px;
margin:0;

color: #000000;

mix-blend-mode: normal;
opacity: 0.5;
`
export const PosterName = styled.p`

font-family: 'Roboto';
font-style: normal;
font-weight: 400;
font-size: 14px;
line-height: 16px;

color: #000000;


margin:0;
`

export const PostMeta = styled.span`

        display: flex;
        flex-direction: column;
        justify-content: space-around;
        margin-left: 30px;
        align-items: flex-start;
        // width: 80%;
        height: 60%;
        flex-grow: 1;
        /* margin:0; */
        padding-top: 0px;
        
        font-family: "Roboto", sans-serif;
        font-weight: normal;
        font-size: 16px;
        padding:0;
        `

export const PosterImg =styled.img`
height: 48px;
width: 48px;
border-radius: 50%;

`

export const PostContent = styled.div`

`

export const PostText = styled.div`
        margin-top: 10px;
        margin-bottom: 10px;
        border: $border_default;
        line-height: 26px;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        align-self: flex-start;
        max-width: 90%;
        word-wrap:break-word;

`

export const PostPictures = styled.div`
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    border: $border_default;
    flex-grow: 1;
    align-items: center;
    gap: 16px;
    min-width:0;
    min-height: 0;
`
export const PostPicture = styled.img`
        width: 260px; 
height: 240px; 
object-fit: cover;
overflow: hidden;
        display: block;
        border-radius: 5%;
`

export const PostPictureSingle = styled.img`
        width: 100%; 
/* height: 240px;  */
object-fit: cover;
overflow: hidden;
        display: block;
        border-radius: 5%;
`


export const PostFooter = styled.div`
display: flex;
    justify-content: flex-start;
    align-items: center;
    // height:10%;
    // width:100%;
    border: $border_default;
    height: 80px;

`

export const PostFooterIcons = styled.div`
display: flex;
        justify-content: flex-start;
        flex-grow: 1;
`

export const PostFooterLikes = styled.p`
align-self: center;
        opacity: 50%;`

export const LikeButton = styled.button`
display: flex;
border: none;
background-color: #ffffff;
font-size: 16px;
font-weight: 400;
margin-right: 40px;
`

export const ShareButton = styled.button`
display: flex;
border: none;
background-color: #ffffff;
font-size: 16px;
font-weight: 400;
margin-right: 40px;
`

export const PostFooterIcon = styled.img`
    margin-right: 10px;
    
`
export const PostFooterIconLiked = styled.img`
    margin-right: 10px;
    /* color: purple; */
    /* background: linear-gradient(132.96deg, #C468FF 3.32%, #6E91F6 100%); */
        box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.07);
    
`

export const MenuIcons =styled.img`
margin-right: 10px;
    max-height: 70%;
`