import styled from "styled-components"

// ?CHANGE MEHRFACH? 
export const BaseInpCont = styled.div`
    display: flex;
    align-self: center;
    align-items: center;
    justify-content: flex-start;
    border-bottom: 1px solid rgba(0, 0, 0, .5);
    width: 260px;
    height: 58px;

    p {
        color: rgba(0, 0, 0, .5);
        font-size: 1.2rem;
        line-height: 12px;
    }

    label {
        margin-right: 15px;
    }

    input {
        width: 100%;
        height: 26px;
    }

`
// ?CHANGE CONNECTION? 
export const StepTwoCont = styled.div`
    img {
        margin-top: calc(43px - 37px);
        margin-bottom: 41px;
        height: 81px;
        width: 81px;
    }

    p {
        color: rgba(0, 0, 0, .5);
        font-size: 1.6rem;
        text-align: center;
    }
`

export const CheckMarkCont = styled.svg`
position: relative;
`

export const circleForCheckMark = styled.div`
position: absolute;
z-index:0;
`

export const CheckMark = styled.div`
position: absolute;
z-index:1;
`