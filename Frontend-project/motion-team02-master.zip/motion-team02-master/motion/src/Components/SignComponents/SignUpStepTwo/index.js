// import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { change_sub } from '../../../redux/slices/login';
// ASSETS
import { ReactComponent as StepTwoIconSVG } from '../../../assets/svgs/step_two.svg';
import { ReactComponent as CircleForCheckMark } from '../../../assets/svgs/circle_for_check_mark.svg';
import { ReactComponent as CheckMark } from '../../../assets/svgs/check_mark.svg';

// IMP STYLED COMPONENTS
import { StepTwoCont, CheckMarkCont } from './styles' 
import { NextStepBtN } from '../../../pages/Login/styles'

const StepTwo = () => {
    
    const dispatch = useDispatch()

    const stepTwoHandler = async e => {
        e.preventDefault()
        dispatch(change_sub("Step Three"))
    }
    
    return (<>
        <StepTwoCont>
            <h2>Congratulations!</h2>
            <CheckMarkCont>
            <CircleForCheckMark id="circleForCheckMark" style={{zIndex:0}}></CircleForCheckMark>
            <CheckMark id="checkMark" style={{zIndex:1}}></CheckMark>
            
            </CheckMarkCont>
            <form onSubmit={stepTwoHandler}>
                <p>We've sent a confirmation code to your email</p>
                <NextStepBtN id="submit" type="submit" value="CONTINUE">CONTINUE</NextStepBtN>
            </form>
            <StepTwoIconSVG id='stepTwoIcon' />
        </StepTwoCont>
    </>)
}

export default StepTwo




// import congrats-LOGO from 
   

   


    