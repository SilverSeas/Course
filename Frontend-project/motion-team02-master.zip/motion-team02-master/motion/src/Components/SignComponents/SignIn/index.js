import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
// IMP ASSETS
import { ReactComponent as UserIconSVG} from '../../../assets/svgs/avatar.svg';
import { ReactComponent as PasswordIconSVG} from '../../../assets/svgs/password.svg';
// IMP STYLED COMPONENTS
import { FormCont, StepLoginCont, PasswordSignInInpCont, UsernameSignInInpCont } from './styles'
import { NextStepBtN } from '../../../pages/Login/styles'
import { useDispatch } from 'react-redux';
import { setToken } from '../../../redux/slices/auth';
import axios from 'axios'



// IMP SLICE ?? -->

const SignIn = () => {

    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const dispatch = useDispatch()
    
    const handleEmail = e => {
        setEmail(e.currentTarget.value);
    }

    const handlePassword = e => {
        setPassword(e.currentTarget.value);
    }

    const handleSubmit = async e => {
        e.preventDefault()
    let config = {
        url: 'https://motion.propulsion-home.ch/backend/api/auth/token/',
        method: 'post',
        data: {
            "email": email,
            "password": password
          },
    }
    let authResponse = await axios(config)
    .catch((er)=>{
        
        alert("login gone wrong")
        
    })
    if (authResponse.data?.access) alert("logedIn")
    localStorage.setItem('access', authResponse.data.access);
    localStorage.setItem('refresh', authResponse.data.refresh);
    
    dispatch(setToken(authResponse.data))
    
    navigate('/feed')

    } 

    return (<>
        <StepLoginCont>
            <form onSubmit={handleSubmit}>
            <h2>Sign In</h2>
                <FormCont>
                    <UsernameSignInInpCont>
                        <label htmlFor="user"><UserIconSVG /></label>
                        <input type="email" id="user" name="email" value={email} onChange={handleEmail} placeholder="Email"></input>
                    </UsernameSignInInpCont>
                    <PasswordSignInInpCont>
                        <label htmlFor="password"><PasswordIconSVG /></label>
                        <input type="password" id="password" name="password" value={password} onChange={handlePassword} placeholder="Password"></input>
                    </PasswordSignInInpCont>
                    {/* {<p>{message}</p>} */}
                </FormCont>
                <NextStepBtN id="submit" type="submit" value="SIGN IN">SIGN IN</NextStepBtN>
            </form>
        </StepLoginCont>
    </>)
}

export default SignIn