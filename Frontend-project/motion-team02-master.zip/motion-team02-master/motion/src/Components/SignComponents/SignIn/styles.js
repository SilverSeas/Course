import styled from 'styled-components'
// ?? 
export const StepLoginCont = styled.div`
`

export const FormCont = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
`

// ??
export const UsernameSignInInpCont = styled.div `
    width: 340px;
`
export const PasswordSignInInpCont = styled(UsernameSignInInpCont)``