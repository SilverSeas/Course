import React from "react";
// import './styles.css'
import { useSelector, useDispatch } from "react-redux";
// import { Navigate, useNavigate } from "react-router-dom";
import { useState } from 'react';
import axios from 'axios'
import { setToken } from "../../../redux/slices/auth"; 
import { useNavigate } from "react-router-dom";
// import { userLogin } from "../../store/user";


const SignInEasy =()=>{

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState()
//   const navigate = useNavigate()
//   const token = useSelector((store)=>store.auth.tokens.oauth)
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const submitHandler = async (e)=>{
    e.preventDefault()
    let config = {
        url: 'https://motion.propulsion-home.ch/backend/api/auth/token/',
        method: 'post',
        data: {
            "email": email,
            "password": password
          },
    }
    let authResponse = await axios(config)
    .catch((er)=>{
        setError(er.response.data)
        alert("login gone wrong")
        // alert(error)
    })
    if (authResponse.data?.access) alert("logedIn")
    localStorage.setItem('access', authResponse.data.access);
    localStorage.setItem('refresh', authResponse.data.refresh);
    // console.log(authResponse.data)
    dispatch(setToken(authResponse.data))
    // dispatch(userLogin(authResponse.data))

    navigate('/feed')
   


  }

 

return (
    <><div className='sign_in_container'>
        <form onSubmit={(e)=>submitHandler(e)}>
            <input className="user_input" value={email} placeholder='email' onChange={(e)=>setEmail(e.target.value)}></input>
            <input className="user_input" type='password' value={password} placeholder='password' onChange={(e)=>setPassword(e.target.value)}></input>
            <button type="Submit">Log-In</button>


        </form>
        </div>
    </>
)


}

export default SignInEasy