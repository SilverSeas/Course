import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { change_sub } from '../../../redux/slices/login';
// IMP ASSETS
import { ReactComponent as EmailIconSVG } from '../../../assets/svgs/mail.svg'; 
import { ReactComponent as StepOneIconSVG } from '../../../assets/svgs/step_one.svg'; 
// IMP STYLED COMPONENTS
import { StepOneCont, EmailSignUpCont } from './styles'
import { NextStepBtN } from '../../../pages/Login/styles.js'

const StepOne = () => {

    const [email, setEmail] = useState('');
    const dispatch = useDispatch()

    const handleEmail = e => {
        setEmail(e.currentTarget.value);
    }

    const stepOneHandler = async e => {
        e.preventDefault();
        const url = "https://motion.propulsion-home.ch/backend/api/auth/registration/";

        const jsBody = {
          email: email
        };
    
        const config = {
          method: "Post",
          headers: new Headers({
            "Content-Type": "application/json",
          }),
          body: JSON.stringify(jsBody),
        };
        fetch(url, config)
            .then(
            (response) => {
            if (response.status === 200){
                dispatch(change_sub("Step Two"))
            }
            else {
                alert("There has been a problem")
                
            }
        })
    }

    return (<>
        <StepOneCont>
            <h2>Sign Up</h2>
            <form onSubmit={stepOneHandler}>
                <EmailSignUpCont>
                    <p>Email</p>
                    <div>
                        <label htmlFor="user"><EmailIconSVG /></label>
                        <input type="text" id="user" name="user" value={email} onChange={handleEmail} placeholder="Email"></input>
                    </div>
                </EmailSignUpCont>
                <NextStepBtN id="submit" type="submit" value="SIGNIN">SIGN IN</NextStepBtN>
            </form>
            <StepOneIconSVG id='stepOneIcon'/>
        </StepOneCont>
    </>)
}    

export default StepOne


    

    

    











