import styled from "styled-components"

// ?CHANGE MEHRFACH? 
export const BaseInpCont = styled.div`
    display: flex;
    align-self: center;
    align-items: center;
    justify-content: flex-start;
    border-bottom: 1px solid rgba(0, 0, 0, .5);
    width: 260px;
    height: 58px;

    p {
        color: rgba(0, 0, 0, .5);
        font-size: 1.2rem;
        line-height: 12px;
        color: white;
    }

    label {
        margin-right: 15px;
    }

    input {
        width: 100%;
        height: 26px;
        color: rgba(0, 0, 0, .5);
        font-size: 1.2rem;
        line-height: 12px;
    }

`

export const StepOneCont = styled.div`

`

export const EmailSignUpCont = styled(BaseInpCont)`

`




