import styled from "styled-components"

export const BaseInpCont = styled.div`
    display: flex;
    align-self: center;
    align-items: center;
    justify-content: flex-start;
    border-bottom: 1px solid rgba(0, 0, 0, .5);
    width: 260px;
    height: 58px;

    p {
        color: rgba(0, 0, 0, .5);
        font-size: 1.2rem;
        line-height: 12px;
    }

    label {
        margin-right: 15px;
    }

    input {
        width: 100%;
        height: 26px;
    }

`

export const StepThreeCont = styled.div`
    h2 {
        margin-bottom: 39px;
    }

    button {
        margin-bottom: 56px;
    }

 
`

export const LayoutContForm = styled.div`
    display: flex;
    justify-content: center;
    flex-direction: row;
`
// - Validation Input longer 
export const ValidationCodeInpCont = styled(BaseInpCont)`
width: 560px;
`
export const LayoutContLeft = styled.div`
    display: flex;
    flex-direction: column;
    margin: 20px;
`
export const EmailInpCont = styled(BaseInpCont)`
    flex-direction: column;
    align-items: flex-start;
`

export const FirstNameInpCont = styled(BaseInpCont)``
export const PasswordInpCont = styled(BaseInpCont)``
export const LayoutContRight = styled(LayoutContLeft)``
export const UsernameInpCont = styled(BaseInpCont)`
    flex-direction: column;
    align-items: flex-start;
`

export const LastNameInpCont = styled(BaseInpCont)``
export const PasswordRepeatInpCont = styled(BaseInpCont)``

export const FormWrapper = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

`

// NextStepBtN FROM LOGINSYTLESSHEET



