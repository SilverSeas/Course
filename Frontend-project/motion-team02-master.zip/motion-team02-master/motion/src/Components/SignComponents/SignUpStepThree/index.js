import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { change_sub } from '../../../redux/slices/login';
// IMP ASSETS
import { ReactComponent as StepThreeIconSVG } from '../../../assets/svgs/step_three.svg';
// IMP STYLED COMPONENTS
import {StepThreeCont, FormWrapper, ValidationCodeInpCont, LayoutContForm, LayoutContLeft, EmailInpCont, FirstNameInpCont, PasswordInpCont, LayoutContRight, UsernameInpCont, LastNameInpCont, PasswordRepeatInpCont } from "./styles"
import { NextStepBtN } from '../../../pages/Login/styles.js'

const StepThree = () => {

    const [validation, setValidation] = useState('');
    const [email, setEmail] = useState('');
    const [username, setUsername] = useState('');
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [password, setPassword] = useState('');
    const [passwordRepeat, setPasswordRepeat] = useState('');
    // const [advisory, setAdvisory] = useState('');
    const dispatch = useDispatch()

    const handleValidationCode = e => {
        setValidation(e.currentTarget.value);
    }
    const handleEmail = e => {
        setEmail(e.currentTarget.value);
    }
    const handleUsername = e => {
        setUsername(e.currentTarget.value);
    }
    const handleFirstName = e => {
        setFirstName(e.currentTarget.value);
    }
    const handleLastName = e => {
        setLastName(e.currentTarget.value);
    }
    const handlePassword = e => {
        setPassword(e.currentTarget.value);
    }
    const handlePasswordRepeat = e => {
        setPasswordRepeat(e.currentTarget.value);
    }

    const stepThreeHandler = async e => {
        e.preventDefault();

        const url = "https://motion.propulsion-home.ch/backend/api/auth/registration/validation/";
        const jsBody = {
            email: email,
            username: username,
            code: validation,
            password: password,
            password_repeat: passwordRepeat,
            first_name: firstName,
            last_name: lastName,
        };

        const config = {
          method: "PATCH",
          headers: new Headers({
            "Content-Type": "application/json",
          }),
          body: JSON.stringify(jsBody),
        };
        fetch(url, config)
            .then(
            (response) => {
                dispatch(change_sub("Sign In"))
        })

        } 
    

    return (<>
        <StepThreeCont>
            <h2>Verification</h2>
            <form onSubmit={stepThreeHandler}>
                <FormWrapper>
                    <ValidationCodeInpCont>
                        <input type="text" id="validation" name="validation" value={validation} onChange={handleValidationCode} placeholder="Validation code"></input>
                    </ValidationCodeInpCont>
                    <LayoutContForm>
                        <LayoutContLeft>
                            <EmailInpCont>
                                <p>Email</p>
                                <input type="text" id="email" name="email" value={email} onChange={handleEmail} placeholder="Email"></input>
                            </EmailInpCont>
                            <FirstNameInpCont>
                                <input type="text" id="firstName" name="firstName" value={firstName} onChange={handleFirstName} placeholder="First name"></input>
                            </FirstNameInpCont>
                            <PasswordInpCont>
                                <input type="password" id="password" name="password" value={password} onChange={handlePassword} placeholder="Password"></input>
                            </PasswordInpCont>
                        </LayoutContLeft>
                        <LayoutContRight>
                            <UsernameInpCont>
                                <p>Username</p>
                                <input type="text" id="user" name="user" value={username} onChange={handleUsername} placeholder="Username"></input>
                            </UsernameInpCont>
                            <LastNameInpCont>
                                <input type="text" id="lastName" name="lastName" value={lastName} onChange={handleLastName} placeholder="Last name"></input>
                            </LastNameInpCont>
                            <PasswordRepeatInpCont>
                                <input type="password" id="passwordRepeat" name="passwordRepeat" value={passwordRepeat} onChange={handlePasswordRepeat} placeholder="Password repeat"></input>
                            </PasswordRepeatInpCont>
                        </LayoutContRight>
                    </LayoutContForm>
                    {/* <p>{advisory}</p> */}
                </FormWrapper>
                <NextStepBtN id="submit" type="submit" value="Complete">COMPLETE</NextStepBtN>
            </form>
            <StepThreeIconSVG id='stepThreeIcon'/>
        </StepThreeCont>
    </>)
}

export default StepThree



